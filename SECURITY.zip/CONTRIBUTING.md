# Contributing to PPG.GCSS.Angular

This repository defines the `PPG.GCSS.Angular` application standard for new PPG.GCSS projects. Contributions should strengthen `PPG.GCSS.Angular` as a reusable standard, not introduce one-off project shortcuts.

## Expectations

- Keep `PPG.GCSS.Angular` aligned with the documented architecture in `.github/instructions/` and `docs/`.
- Prefer Nx monorepo conventions, vertical slice architecture, SSR with hydration, standalone components, signals, OnPush change detection, schema-driven forms, and the design-system-first approach.
- Keep changes incremental and focused. Avoid broad rewrites unless the repository owners explicitly request them.
- Update documentation when behavior, structure, or team conventions change.

## Workflow

- Start from the existing feature, library, or instruction pattern before creating a new abstraction.
- Keep feature-specific code inside the owning slice. Move code into `libs/` only when it is genuinely reusable.
- Preserve dependency boundaries between app, feature, ui, core, shared, and design-system layers.
- Add or update tests when code behavior changes.
- Keep pull requests small enough to review effectively.

## Code Standards

- Use strict TypeScript and avoid `any`.
- Do not leak DTOs directly into UI-facing code.
- Prefer typed view models, typed schemas, and explicit mapping at boundaries.
- Reuse `ui-*` libraries and design-system tokens instead of duplicating UI primitives.
- Keep `PPG.GCSS.Angular` simple and push non-trivial logic into TypeScript.

## Documentation Standards

- Treat `.github/` and `docs/` as part of the product, not as optional metadata.
- When architecture rules change, update the relevant instruction or skill file in the same change.
- Record significant architectural choices as ADRs under `docs/architecture/decisions/` when appropriate.

## Pull Request Checklist

- The change fits the `PPG.GCSS.Angular` target architecture.
- The change does not break Nx dependency boundaries.
- Documentation was updated where needed.
- Tests were added or adjusted when behavior changed.
- The change can be reused by future projects without project-specific assumptions.