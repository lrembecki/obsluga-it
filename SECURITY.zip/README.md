# PPG.GCSS.Angular Template

This repository defines and demonstrates the baseline standard for `PPG.GCSS.Angular`. It now includes a runnable Nx Angular SSR workspace with one thin application shell, core and shared foundations, representative feature libraries, and the `.github/` guidance and `docs/` assets that govern the standard.

## Overview

The baseline is centered on a small set of required defaults:

- Nx monorepo structure
- Angular SSR with hydration
- Thin applications in `apps/`
- Vertical slice feature libraries in `libs/features/<domain>`
- Standalone Angular components
- Signals-first local state
- OnPush change detection by default
- Schema-driven forms for business flows
- PrimeNG-backed UI through approved `ui` layers
- Jest unit testing, ESLint, and Playwright e2e wiring

These defaults are documented in `.github/instructions/` and represented directly in the workspace source.

## Repository Purpose

Use this repository as the reusable starting baseline for `PPG.GCSS.Angular` when you need:

- A runnable Nx Angular SSR workspace instead of a docs-only standard
- A consistent project structure across teams
- Clear dependency boundaries between app, feature, core, and shared layers
- Reusable Copilot instructions, skills, ADRs, technical designs, and plans alongside the codebase

## Repository Structure

```text
.
├── apps/
│   ├── ppg-gcss-angular/           # Thin Angular SSR application shell
│   └── ppg-gcss-angular-e2e/       # Playwright end-to-end project
├── libs/
│   ├── core/                       # Runtime config and translation infrastructure
│   ├── features/
│   │   ├── users/
│   │   ├── tenants/
│   │   ├── permissions/
│   │   ├── tenant-user-permissions/
│   │   ├── products/
│   │   ├── batches/
│   │   └── customers/
│   └── shared/
│       ├── ui/                     # Shared UI, layout, tokens, translation primitives
│       ├── utils/                  # Pure helpers and schema/form types
│       └── forms/                  # Shared schema-form surface
├── .github/                        # Workspace instructions and Copilot skills
├── docs/                           # ADRs, technical designs, and implementation plans
├── package.json
├── nx.json
└── tsconfig.base.json
```

The application shell composes the workspace around top-level `admin` and `catalog` areas. Business behavior stays in libraries under `libs/`.

## Getting Started

### Prerequisites

- Node.js 24+
- npm 11+

### Install Dependencies

```bash
npm install
```

### Run Locally

```bash
npm start
```

Equivalent direct Nx command:

```bash
npx nx serve ppg-gcss-angular
```

The default dev server uses the development configuration for the SSR app.

## Validate The Baseline

Use the root scripts for the main workspace checks:

- `npm run format:check`
- `npm run lint`
- `npm run test`
- `npm run build:dev`
- `npm run build`

Use the direct Nx command when you need coverage:

- `npx nx run-many -t test --all --configuration=ci`

The root package scripts cover format, lint, unit test, and build. Running the app uses the Nx `serve` target directly.

## Engineering Standards

- Angular code should follow the workspace instructions in `.github/instructions/`.
- Applications should remain thin; business behavior belongs in `libs/features`.
- SSR with hydration should remain enabled for `ppg-gcss-angular`.
- Libraries should export public APIs through `src/index.ts`.
- PrimeNG imports should remain inside approved `ui` layers.
- Documentation changes should ship with architecture or workflow changes.

## Documentation

- `docs/architecture/decisions/` stores architecture decision records.
- `docs/technical-designs/` stores solution designs and deeper implementation notes.
- `docs/plans/` stores delivery or refactoring plans.

Use the ADR template in `docs/architecture/decisions/0000-adr-template.md` when documenting new architectural decisions.

## Contributing

See `CONTRIBUTING.md` for contribution expectations, workflow, and review criteria.

## Security

See `SECURITY.md` for vulnerability reporting guidance and secure contribution expectations.

## Maintenance Notes

- Keep `.github/instructions/` and `.github/skills/` in sync when architecture rules change.
- Keep the runnable workspace aligned with the documented baseline.
- Prefer incremental updates over broad rewrites.
- Remove placeholders quickly; avoid leaving TODO-only guidance in the baseline template.
