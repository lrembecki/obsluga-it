# Transloco Standard For Angular Projects

## Purpose

Use Transloco as the default runtime translation solution when the application needs language switching without a rebuild or redeployment.

This document targets Angular 20+ applications that use standalone bootstrap and Nx-style project structure.

This document covers the internal Transloco integration used inside `libs/core/i18n`. For the public application-facing API, usage patterns, and lightweight custom service, pipe, and directive, read [translations.md](translations.md).

## Why Transloco

Choose Transloco over Angular i18n or `ngx-translate` when the project needs:

- runtime language switching
- JSON translation assets
- Angular-friendly dependency injection and feature organization
- a modern path for Angular 20+ applications

Angular i18n is still valid for static, build-time localized sites, but it is not the default when the team does not want translation changes tied to application deployment.

For Angular 20+, use the maintained `@jsverse/transloco` package family. The older `@ngneat/transloco` packages no longer receive updates.

## Angular 20+ Baseline

- Use standalone application bootstrap with `app.config.ts`.
- Use `@jsverse/transloco` and matching `@jsverse/transloco-*` plugin packages.
- Keep runtime translations in `src/assets/i18n/*.json`.
- Keep Transloco runtime infrastructure in `libs/core/i18n`.
- Keep `TranslocoService` inside `core/i18n` and expose app-facing behavior through a custom `TranslationsService`.
- Keep lightweight `TranslatePipe` and `TranslateDirective` in `libs/shared/ui`.
- Keep all `@jsverse/transloco` imports inside `libs/core/i18n`.
- Do not create a new dedicated `translations` library under `libs` for this pattern.

## Workspace Alignment

To stay aligned with the Angular application standard in this workspace:

- treat translations as app-wide runtime infrastructure, not as feature-owned code
- keep `core/i18n` in `libs/core` because it is app-wide runtime infrastructure
- keep `TranslatePipe` and `TranslateDirective` in `libs/shared/ui` because they are stateless reusable presentation primitives
- keep application copy in `apps/<app-name>/src/assets/i18n/*.json`
- export runtime APIs through `libs/core/i18n/index.ts`
- export presentation primitives through `libs/shared/ui/src/index.ts`
- keep `transloco.loader.ts` and raw Transloco config private to `core/i18n`
- point workspace path aliases at those `index.ts` files
- keep `app.config.ts` focused on composing providers from `@project/core/i18n`
- do not introduce `TranslocoRootModule` or any other NgModule-based translation setup for new work
- do not keep app-local `transloco.loader.ts`, `translation.service.ts`, or `transloco.config.ts` files once the layer exists
- do not import `@jsverse/transloco` symbols outside `libs/core/i18n`

If the workspace enforces strict `shared` to `core` isolation, keep the folder layout below but inject the runtime behind a shared abstraction token rather than importing `@project/core/i18n` directly from shared primitives.

## Default Asset Layout

Keep application translation assets in the Angular app's assets folder:

```text
apps/<app-name>/src/assets/i18n/
├── en.json
└── es.json
```

At runtime, the loader should read from `/assets/i18n/<lang>.json`.

Do not scatter app-level translation files across features or libraries by default. Keep one file per language unless the team deliberately introduces a split-asset strategy.

Recommended file placement for an Angular 20+ app:

```text
apps/<app-name>/
├── src/
│   ├── app/
│   │   └── app.config.ts
│   └── assets/i18n/
│       ├── en.json
│       └── es.json
libs/
├── core/
│   └── i18n/
│       ├── translation.service.ts
│       ├── transloco.config.ts
│       ├── transloco.loader.ts
│       └── index.ts
└── shared/
  └── ui/
      └── src/
          ├── index.ts
          └── lib/
              ├── directives/
              │   └── translate.directive.ts
              └── pipes/
                  └── translate.pipe.ts
```

The application owns the translation content in `apps/<app-name>/src/assets/i18n/*.json`. The reusable runtime infrastructure lives in `libs/core/i18n`, and the custom template primitives live in `libs/shared/ui`.

Application code should consume only the custom public APIs from `@project/core/i18n` and `@project/shared/ui`. Transloco remains an internal implementation detail.

## Root Setup

The Transloco docs recommend schematics for initial setup. In an Nx workspace, treat generator output as a starting point only. The generated files should be normalized to the workspace standard:

- move Transloco runtime infrastructure into `libs/core/i18n`
- move custom `TranslatePipe` and `TranslateDirective` into `libs/shared/ui`
- keep only `app.config.ts` and `assets/i18n/*.json` in the application
- remove any generated app-local `transloco.loader.ts` or `transloco-root.module.ts`

If you want the generator to scaffold the initial files for a specific app:

```bash
npm install @jsverse/transloco
nx g @jsverse/transloco:ng-add --project=<app-name>
```

If you prefer manual setup, install Transloco:

```bash
npm install @jsverse/transloco
```

Create the loader inside `libs/core/i18n`:

```ts
import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Translation, TranslocoLoader } from '@jsverse/transloco';

@Injectable({ providedIn: 'root' })
export class TranslocoHttpLoader implements TranslocoLoader {
  private readonly http = inject(HttpClient);

  getTranslation(lang: string) {
    return this.http.get<Translation>(`/assets/i18n/${lang}.json`);
  }
}
```

Keep `transloco.config.ts` in `core/i18n` so runtime configuration, provider helpers, persistence helpers, and tooling configuration stay in one place:

```ts
import {
  EnvironmentProviders,
  isDevMode,
  makeEnvironmentProviders,
} from '@angular/core';
import { provideTransloco, TranslocoConfig, translocoConfig } from '@jsverse/transloco';
import {
  cookiesStorage,
  provideTranslocoPersistLang,
} from '@jsverse/transloco-persist-lang';
import { TranslocoGlobalConfig } from '@jsverse/transloco-utils';

import { TranslocoHttpLoader } from './transloco.loader';

const translocoRootConfig: TranslocoConfig = translocoConfig({
  availableLangs: ['en', 'es'],
  defaultLang: 'en',
  fallbackLang: 'en',
  reRenderOnLangChange: true,
  prodMode: !isDevMode(),
});

export function provideTranslations(): EnvironmentProviders {
  return makeEnvironmentProviders([
    provideTransloco({
      config: translocoRootConfig,
      loader: TranslocoHttpLoader,
    }),
  ]);
}

export function provideTranslationPersistence(): EnvironmentProviders {
  return makeEnvironmentProviders([
    provideTranslocoPersistLang({
      storage: {
        useValue: cookiesStorage(),
      },
    }),
  ]);
}

const config: TranslocoGlobalConfig = {
  rootTranslationsPath: 'apps/<app-name>/src/assets/i18n/',
  langs: ['en', 'es'],
  keysManager: {},
};

export default config;
```

Expose runtime APIs through `libs/core/i18n/index.ts`:

```ts
export * from './translation.service';
export {
  provideTranslationPersistence,
  provideTranslations,
} from './transloco.config';
```

Expose presentation primitives through `libs/shared/ui/src/index.ts`:

```ts
export * from './pipes/translate.pipe';
export * from './directives/translate.directive';
```

Keep `transloco.loader.ts` private to the internal runtime implementation, and do not expose raw Transloco config objects through the public API.

Register translations once at the application root in `app.config.ts` by importing from `@project/core/i18n`:

```ts
import { ApplicationConfig } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';

import {
  provideTranslationPersistence,
  provideTranslations,
} from '@project/core/i18n';

export const appConfig: ApplicationConfig = {
  providers: [
    provideHttpClient(),
    provideTranslations(),
    provideTranslationPersistence(),
  ],
};
```

If deployed assets do not resolve correctly, Transloco documents using a relative loader path as an alternative:

```ts
getTranslation(lang: string) {
  return this.http.get<Translation>(`./assets/i18n/${lang}.json`);
}
```

If you use Transloco tooling such as key extraction, keep `transloco.config.ts` in `core/i18n` and point `rootTranslationsPath` at the consuming app's assets folder:

```ts
import { TranslocoGlobalConfig } from '@jsverse/transloco-utils';

const config: TranslocoGlobalConfig = {
  rootTranslationsPath: 'apps/<app-name>/src/assets/i18n/',
  langs: ['en', 'es'],
  keysManager: {},
};

export default config;
```

This keeps the Nx boundary clear:

- the app owns translation assets and root composition
- `core/i18n` owns loader, wrapper service, provider helpers, persistence helpers, and Transloco config
- `shared/ui` owns the custom pipe and directive
- the rest of the application imports only `@project/core/i18n` and `@project/shared/ui`

## Internal Wrapper Service

Do not inject `TranslocoService` directly across components, routes, facades, or feature services.

Create `TranslationsService` inside `libs/core/i18n/translation.service.ts` and make the rest of the TypeScript code depend on `@project/core/i18n` instead. This keeps the third-party dependency behind a controlled boundary and makes migration or replacement easier later.

The full public wrapper API is described in [translations.md](translations.md). The example below shows the internal service boundary that delegates to Transloco without leaking direct package usage into the rest of the application.

```ts
import { Injectable, inject } from '@angular/core';
import { TranslocoService } from '@jsverse/transloco';
import { Observable, map } from 'rxjs';

export type TranslationParams = Record<
  string,
  string | number | boolean | null | undefined
>;

export type LanguageOption =
  | string
  | Readonly<{
      id: string;
      label?: string;
    }>;

@Injectable({ providedIn: 'root' })
export class TranslationsService {
  private readonly transloco = inject(TranslocoService);

  readonly langChanges$ = this.transloco.langChanges$;

  getActiveLang(): string {
    return this.transloco.getActiveLang();
  }

  getAvailableLangs(): LanguageOption[] {
    return this.transloco.getAvailableLangs().map((lang) =>
      typeof lang === 'string'
        ? lang
        : { id: lang.id, label: lang.label },
    );
  }

  setActiveLang(lang: string): void {
    this.transloco.setActiveLang(lang);
  }

  preloadLanguage(lang: string): Observable<void> {
    return this.transloco.load(lang).pipe(map(() => void 0));
  }

  translate(key: string, params?: TranslationParams, lang?: string): string {
    return this.transloco.translate(key, params, lang);
  }

  selectTranslate(
    key: string,
    params?: TranslationParams,
    lang?: string,
  ): Observable<string> {
    return this.transloco.selectTranslate(key, params, lang);
  }
}
```

Guidelines for the wrapper:

- expand the wrapper only with the methods the application actually uses
- prefer `selectTranslate()` over `translate()` when the translation may not be loaded yet
- keep `TranslocoService` imports limited to translation infrastructure files such as the wrapper, loader, or specialized initializers
- export the wrapper through `libs/core/i18n/index.ts` and consume it via `@project/core/i18n`
- keep the wrapper focused on infrastructure concerns, not feature business logic
- do not leak Transloco-specific runtime types through the public wrapper unless there is a clear need

## Translation File Shape

Use stable, namespaced keys in each language file:

```json
{
  "app": {
    "title": "Portal"
  },
  "badgeLoginPage": {
    "header": "Badge login"
  },
  "users": {
    "list": {
      "title": "Users",
      "empty": "No users found"
    }
  }
}
```

Guidelines:

- namespace keys by app area, feature, page, or reusable domain
- keep the same key structure in every language file
- prefer explicit keys over long free-form sentences as identifiers
- avoid generating keys dynamically unless the allowed key set is tightly controlled

## Using The Custom Library In Components

Application code should import the custom service from `@project/core/i18n` and the custom pipe and directive from `@project/shared/ui`.

Do not import `TranslocoService`, `TranslocoPipe`, or `TranslocoDirective` outside `libs/core/i18n`. For the full public guidance, read [translations.md](translations.md).

```ts
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TranslationsService } from '@project/core/i18n';
import { TranslateDirective, TranslatePipe } from '@project/shared/ui';

@Component({
  selector: 'app-language-switcher',
  standalone: true,
  imports: [TranslatePipe, TranslateDirective],
  templateUrl: './language-switcher.component.html',
  styleUrl: './language-switcher.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LanguageSwitcherComponent {
  private readonly translations = inject(TranslationsService);

  changeLang(lang: string): void {
    this.translations.setActiveLang(lang);
  }
}
```

`language-switcher.component.html`:

```html
<h2>{{ 'settings.language.title' | translate }}</h2>
<button
  type="button"
  [translate]="'settings.language.english'"
  (click)="changeLang('en')"
></button>
<button
  type="button"
  [translate]="'settings.language.spanish'"
  (click)="changeLang('es')"
></button>
```

Use the custom directive for lightweight host text content or a single attribute. Use the custom pipe for interpolation-heavy bindings. If the application needs more advanced template composition, extend the custom library instead of importing Transloco directives directly.

```html
<h1>{{ 'app.title' | translate }}</h1>
<h3>{{ 'badgeLoginPage.header' | translate }}</h3>
<span [title]="'app.title' | translate"></span>
<img [translate]="'profile.avatarAlt'" translateAttr="alt" />
```

In TypeScript, use the custom service instead of `TranslocoService` directly:

```ts
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';

import { TranslationsService } from '@project/core/i18n';

@Component({
  selector: 'app-language-switcher',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LanguageSwitcherComponent {
  private readonly translations = inject(TranslationsService);

  changeLang(lang: string): void {
    this.translations.setActiveLang(lang);
  }
}
```

Use service-based translation sparingly. Prefer keeping copy close to the template unless the string is part of metadata, notifications, titles, page composition, or other non-template flows.

For reactive TypeScript consumption, prefer the wrapper's observable methods:

```ts
readonly title$ = this.translations.selectTranslate('users.list.title');
```

Avoid calling synchronous `translate()` before the language file is loaded.

## Project-Wide Usage Rules

- App shell code owns the root Transloco provider, available languages, default language, and persistence strategy.
- `app.config.ts` wires translation providers from `@project/core/i18n` instead of declaring the loader, wrapper service, or root config inline.
- Prefer a library-exported `provideTranslations()` helper so app composition stays small and explicit.
- Application TypeScript code depends on `TranslationsService` from `@project/core/i18n`, not on `TranslocoService`.
- Application templates depend on `TranslatePipe` and `TranslateDirective` from `@project/shared/ui`, not on Transloco template primitives.
- Features should use namespaced keys such as `orders.create.title` or `users.list.empty`.
- Shared and UI libraries should stay copy-agnostic when practical. Pass already translated labels or translation keys from the owning application or feature instead of baking app-specific text into generic libraries.
- Keep translation keys stable across refactors to avoid unnecessary translation churn.
- Do not hide translation lookups inside low-level utility functions unless that utility's responsibility is presentation.
- For route titles, notifications, dialogs, and page metadata, translate in the feature boundary rather than deep in reusable infrastructure.
- If you later adopt Transloco signal helpers, expose them through the same application boundary instead of importing third-party translation helpers throughout the app.
- Do not keep duplicate translation infrastructure in both the app and the library.
- Do not bypass the public API with deep imports into `libs/core/i18n/*` or `libs/shared/*` internals.
- Do not import any `@jsverse/transloco` symbols outside `libs/core/i18n`.

## SSR And Browser APIs

Transloco itself works well with SSR, but language detection and persistence still need browser guards.

- Do not read `window`, `localStorage`, `sessionStorage`, or `navigator.language` during server rendering.
- If you persist the active language, only read or write storage in browser-only code paths.
- Keep the server render deterministic by falling back to the configured default language when no browser context is available.

For persisted language in SSR scenarios, Transloco documents the `@jsverse/transloco-persist-lang` plugin and its cookie storage option:

```bash
npm install @jsverse/transloco-persist-lang
```

```ts
import { EnvironmentProviders, makeEnvironmentProviders } from '@angular/core';
import { provideTranslocoPersistLang, cookiesStorage } from '@jsverse/transloco-persist-lang';

export function provideTranslationPersistence(): EnvironmentProviders {
  return makeEnvironmentProviders([
    provideTranslocoPersistLang({
      storage: {
        useValue: cookiesStorage(),
      },
    }),
  ]);
}
```

Then keep application composition in `app.config.ts` focused on library exports:

```ts
import { ApplicationConfig } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';
import {
  provideTranslationPersistence,
  provideTranslations,
} from '@project/core/i18n';

export const appConfig: ApplicationConfig = {
  providers: [
    provideHttpClient(),
    provideTranslations(),
    provideTranslationPersistence(),
  ],
};
```

Use cookie-based persistence when SSR matters. Use `localStorage` only in browser-only applications or behind an explicit browser guard.

If the active language comes from user profile data, preload it during startup through an initializer and call the wrapper service rather than spreading direct `TranslocoService` usage into app composition code.

## Optional Scoped Files

The default workspace standard is one file per language in `assets/i18n/*.json`.

If a feature becomes large enough that lazy-loaded translation scopes are justified, that is a deliberate deviation from the default layout. Only do this when the asset strategy is documented and consistent.

Keep the same public boundary even in that case: use Transloco scopes inside `core/i18n`, then expose a custom provider helper from there instead of importing Transloco scope APIs directly in application code.

```ts
import { EnvironmentProviders, makeEnvironmentProviders } from '@angular/core';
import { provideTranslocoScope } from '@jsverse/transloco';

export function provideUsersTranslations(): EnvironmentProviders {
  return makeEnvironmentProviders([
    provideTranslocoScope('users'),
  ]);
}
```

Then application or feature code can continue to consume only the custom runtime alias:

```ts
import { Route } from '@angular/router';

import { provideUsersTranslations } from '@project/core/i18n';

export const USERS_ROUTES: Route[] = [
  {
    path: '',
    loadComponent: () =>
      import('./users-page.component').then((module) => module.UsersPageComponent),
    providers: [provideUsersTranslations()],
  },
];
```

Scopes still follow Angular DI boundaries. Transloco documents them as valid in lazy route providers, component providers, or inline in the structural directive, but those details should stay inside the custom library whenever possible.

Do not mix root-only JSON files and ad hoc scoped-file conventions without documenting how each scope is loaded.

## Migration Guidance

When migrating from Angular i18n or `ngx-translate`:

- choose Transloco when the project wants runtime language switching and JSON assets
- migrate to the maintained `@jsverse/transloco` package family for Angular 20+
- move translation content into `assets/i18n/*.json`
- move `translation.service.ts`, `transloco.loader.ts`, and `transloco.config.ts` into `libs/core/i18n`
- move `TranslatePipe` and `TranslateDirective` into `libs/shared/ui`
- add provider helpers such as `provideTranslations()` to `core/i18n/index.ts`
- register one root Transloco provider before refactoring call sites
- introduce `TranslationsService`, `TranslatePipe`, and `TranslateDirective` early and migrate application code to those custom wrappers instead of depending on third-party services directly
- replace old translation pipes, directives, and service calls incrementally with the custom translation layer
- keep key names stable where practical to reduce migration noise
- remove any leftover app-local Transloco files or NgModule-based setup after the migration is complete

## Review Checklist

- Transloco is configured once at the application root
- Transloco runtime infrastructure is defined in `libs/core/i18n`
- `TranslocoService` is wrapped by one application-facing `TranslationsService` exported from `libs/core/i18n`
- The runtime public API is exported through `libs/core/i18n/index.ts`
- The template public API is exported through `libs/shared/ui/src/index.ts`
- The public API exposes custom wrappers such as `TranslationsService`, `TranslatePipe`, `TranslateDirective`, and provider helpers
- `app.config.ts` composes library exports such as `provideTranslations()` instead of inlining Transloco setup
- Translation assets live in `src/assets/i18n/*.json`
- Runtime URL resolves to `/assets/i18n/<lang>.json`
- Keys are namespaced and consistent across languages
- Language switching in application code goes through `TranslationsService`
- Application templates use the custom pipe and directive instead of direct Transloco primitives
- Browser-only persistence or detection is SSR-safe
- Shared libraries are not coupled to app-specific copy
- No app-local `transloco.loader.ts`, `translation.service.ts`, `transloco.config.ts`, or `TranslocoRootModule` remain after the shared layer pattern is adopted
- No `@jsverse/transloco` imports appear outside `libs/core/i18n`