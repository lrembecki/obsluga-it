# Custom Translation Layer

## Purpose

Use this document for the public, application-facing translation layer split across `libs/core/i18n` and `libs/shared/ui`.

Application, feature, shared, and UI code should use only this custom surface. Transloco is the internal implementation detail behind `libs/core/i18n` and should not be imported directly outside that folder.

For the internal Transloco wiring behind this layer, read [transloco.md](transloco.md).

## Public API Surface

The custom translation layer should expose only the stable application-facing surface.

From `@project/core/i18n`:

- `TranslationsService`
- `provideTranslations()`
- `provideTranslationPersistence()` when needed
- lightweight shared types such as `TranslationParams`

From `@project/shared/ui`:

- `TranslatePipe`
- `TranslateDirective`

Do not expose `TranslocoService`, `TranslocoPipe`, `TranslocoDirective`, `TranslocoLoader`, or Transloco config objects through the public API.

## Structure

```text
libs/
├── core/
│   └── i18n/
│       ├── translation.service.ts
│       ├── transloco.config.ts
│       ├── transloco.loader.ts
│       └── index.ts
├── shared/
│   └── ui/
│       └── src/
│           ├── index.ts
│           └── lib/
│               ├── directives/
│               │   └── translate.directive.ts
│               └── pipes/
│                   └── translate.pipe.ts
```

This pattern does not introduce a new dedicated library under `libs`. It reuses the existing workspace areas:

- `libs/core/i18n` owns runtime, provider composition, SSR, persistence, and third-party integration
- `libs/shared/ui` owns thin stateless presentation primitives used in templates
- app code imports from `@project/core/i18n` and `@project/shared/ui`

If the workspace enforces strict `shared` to `core` isolation, keep the same folder layout but bridge `TranslatePipe` and `TranslateDirective` to the runtime through a shared abstraction token instead of a direct core import.

## Public API Rules

- import runtime translation functionality only from `@project/core/i18n`
- import template translation primitives only from `@project/shared/ui`
- keep the public API smaller than the underlying Transloco feature set
- keep third-party types out of the public API where practical
- keep the pipe and directive thin, stateless, and feature-agnostic
- if the application later needs more translation behavior, extend the custom layer instead of importing Transloco directly

## `TranslationsService`

`TranslationsService` is the public imperative API used throughout the application. It wraps Transloco internally but exposes application-friendly methods and custom types.

Suggested file: `libs/core/i18n/translation.service.ts`

```ts
import { Injectable, inject } from '@angular/core';
import { TranslocoService } from '@jsverse/transloco';
import { Observable, map } from 'rxjs';

export type TranslationParams = Readonly<
  Record<string, string | number | boolean | null | undefined>
>;

export type LanguageOption =
  | string
  | Readonly<{
      id: string;
      label?: string;
    }>;

@Injectable({ providedIn: 'root' })
export class TranslationsService {
  private readonly transloco = inject(TranslocoService);

  readonly langChanges$ = this.transloco.langChanges$;

  getActiveLang(): string {
    return this.transloco.getActiveLang();
  }

  getAvailableLangs(): LanguageOption[] {
    return this.transloco.getAvailableLangs().map((lang) =>
      typeof lang === 'string'
        ? lang
        : { id: lang.id, label: lang.label },
    );
  }

  setActiveLang(lang: string): void {
    this.transloco.setActiveLang(lang);
  }

  preloadLanguage(lang: string): Observable<void> {
    return this.transloco.load(lang).pipe(map(() => void 0));
  }

  translate(key: string, params?: TranslationParams, lang?: string): string {
    return this.transloco.translate(key, params, lang);
  }

  selectTranslate(
    key: string,
    params?: TranslationParams,
    lang?: string,
  ): Observable<string> {
    return this.transloco.selectTranslate(key, params, lang);
  }
}
```

Guidelines:

- keep the service focused on translation infrastructure, not feature business logic
- prefer `selectTranslate()` for reactive flows or when the language file may not be loaded yet
- do not leak Transloco-specific runtime types from the public service contract

## `TranslatePipe`

Use a lightweight custom pipe for common template bindings. The pipe should depend on `TranslationsService`, not on Transloco symbols directly.

Suggested file: `libs/shared/ui/src/lib/pipes/translate.pipe.ts`

```ts
import {
  ChangeDetectorRef,
  DestroyRef,
  Pipe,
  PipeTransform,
  inject,
} from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';

import { TranslationParams, TranslationsService } from '@project/core/i18n';

@Pipe({
  name: 'translate',
  standalone: true,
  pure: false,
})
export class TranslatePipe implements PipeTransform {
  private readonly translations = inject(TranslationsService);
  private readonly changeDetectorRef = inject(ChangeDetectorRef);
  private readonly destroyRef = inject(DestroyRef);

  constructor() {
    this.translations.langChanges$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(() => this.changeDetectorRef.markForCheck());
  }

  transform(key: string, params?: TranslationParams, lang?: string): string {
    return this.translations.translate(key, params, lang);
  }
}
```

Keep the pipe simple. It should remain a stateless presentation adapter over the custom runtime service.

## `TranslateDirective`

Use a lightweight custom directive for host text content or a single translated attribute.

Suggested file: `libs/shared/ui/src/lib/directives/translate.directive.ts`

```ts
import {
  Directive,
  ElementRef,
  Renderer2,
  effect,
  inject,
  input,
} from '@angular/core';
import { Subscription } from 'rxjs';

import { TranslationParams, TranslationsService } from '@project/core/i18n';

@Directive({
  selector: '[translate]',
  standalone: true,
})
export class TranslateDirective {
  readonly key = input.required<string>({ alias: 'translate' });
  readonly params = input<TranslationParams | undefined>(undefined, {
    alias: 'translateParams',
  });
  readonly lang = input<string | undefined>(undefined, {
    alias: 'translateLang',
  });
  readonly attr = input<string | undefined>(undefined, {
    alias: 'translateAttr',
  });

  private readonly elementRef = inject(ElementRef<HTMLElement>);
  private readonly renderer = inject(Renderer2);
  private readonly translations = inject(TranslationsService);

  private subscription?: Subscription;

  constructor() {
    effect((onCleanup) => {
      const key = this.key();
      const params = this.params();
      const lang = this.lang();
      const attr = this.attr();

      this.subscription?.unsubscribe();
      this.subscription = this.translations
        .selectTranslate(key, params, lang)
        .subscribe((value) => {
          if (attr) {
            this.renderer.setAttribute(this.elementRef.nativeElement, attr, value);
            return;
          }

          this.renderer.setProperty(
            this.elementRef.nativeElement,
            'textContent',
            value,
          );
        });

      onCleanup(() => this.subscription?.unsubscribe());
    });
  }
}
```

Keep the directive intentionally small. It should not try to mirror every capability of Transloco's structural directive.

## Public Exports

Expose runtime APIs through `libs/core/i18n/index.ts`:

```ts
export * from './translation.service';
export {
  provideTranslationPersistence,
  provideTranslations,
} from './transloco.config';
```

Expose presentation adapters through `libs/shared/ui/src/index.ts`:

```ts
export * from './pipes/translate.pipe';
export * from './directives/translate.directive';
```

Keep `transloco.loader.ts` and the raw Transloco config private to the internal runtime implementation.

## App Composition

The application config should compose only provider helpers from `@project/core/i18n`:

```ts
import { ApplicationConfig } from '@angular/core';
import { provideHttpClient } from '@angular/common/http';

import {
  provideTranslationPersistence,
  provideTranslations,
} from '@project/core/i18n';

export const appConfig: ApplicationConfig = {
  providers: [
    provideHttpClient(),
    provideTranslations(),
    provideTranslationPersistence(),
  ],
};
```

## Application Usage

Across the application, use only the custom service, pipe, and directive:

```ts
import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { TranslationsService } from '@project/core/i18n';
import { TranslateDirective, TranslatePipe } from '@project/shared/ui';

@Component({
  selector: 'app-language-switcher',
  standalone: true,
  imports: [TranslatePipe, TranslateDirective],
  templateUrl: './language-switcher.component.html',
  styleUrl: './language-switcher.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LanguageSwitcherComponent {
  private readonly translations = inject(TranslationsService);

  readonly title$ = this.translations.selectTranslate('settings.language.title');

  changeLang(lang: string): void {
    this.translations.setActiveLang(lang);
  }
}
```

`language-switcher.component.html`:

```html
<h2>{{ 'settings.language.title' | translate }}</h2>

<button
  type="button"
  [translate]="'settings.language.english'"
  (click)="changeLang('en')"
></button>

<button
  type="button"
  [translate]="'settings.language.spanish'"
  (click)="changeLang('es')"
></button>
```

For attribute translation:

```html
<img
  src="/assets/avatar.png"
  [translate]="'profile.avatarAlt'"
  translateAttr="alt"
/>
```

## Anti-Patterns

- creating a new dedicated `translations` library under `libs`
- importing `@jsverse/transloco` in `apps/`, `features/`, `shared/`, or `ui/` code
- importing `TranslocoPipe`, `TranslocoDirective`, or `TranslocoService` outside `libs/core/i18n`
- exposing raw Transloco config or loader classes through `@project/core/i18n`
- cloning the entire third-party directive API into the custom directive
- keeping duplicate translation service, pipe, or directive implementations in features or apps

## Review Checklist

- Application runtime code imports only from `@project/core/i18n`
- Application template primitives import only from `@project/shared/ui`
- The public surface is `TranslationsService`, `TranslatePipe`, `TranslateDirective`, and provider helpers
- `transloco.loader.ts` and raw Transloco config stay internal to `core/i18n`
- The custom service does not leak third-party types unnecessarily
- The custom directive remains lightweight and focused on host text or attribute translation
- `app.config.ts` composes provider helpers from `@project/core/i18n`