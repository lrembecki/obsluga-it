---
name: angular-translations
description: "Use when implementing, configuring, reviewing, or migrating Angular translations with a custom translation layer backed by Transloco; adding runtime language switching; organizing assets/i18n/*.json; wiring TranslationsService from core/i18n plus shared/ui TranslatePipe, TranslateDirective, provider helpers, or translation keys across the project."
---

# Angular Translations

Use this skill to standardize runtime translations in Angular applications in this workspace.

## Project Default

The default translation standard for Angular projects in this workspace is:

- A custom translation layer split across `libs/core/i18n` and `libs/shared/ui`
- JSON translation assets stored under `src/assets/i18n/*.json` and served from `/assets/i18n/*.json`
- Runtime translation infrastructure files such as `translation.service.ts`, `transloco.loader.ts`, and `transloco.config.ts` live in `libs/core/i18n`
- `app.config.ts` only wires provider helpers from `@project/core/i18n`
- One application-facing `TranslationsService` is exported from `@project/core/i18n`
- Lightweight `TranslatePipe` and `TranslateDirective` are exported from `@project/shared/ui`
- `@jsverse/transloco` is used only inside `libs/core/i18n` as an internal implementation detail
- Namespaced keys owned by the app, feature, or page
- SSR-safe language detection and persistence

## When To Use

Use this skill when you need to:

- add Transloco to a new or existing Angular application
- standardize translation file layout
- implement language switching
- translate templates, pages, feature slices, or shared Angular UI
- review or migrate existing `@angular/localize` or `ngx-translate` usage

## Reference Map

- For the public application-facing translation layer, service, pipe, directive, and usage examples, read [translations.md](references/translations.md).
- For internal Transloco wiring behind `core/i18n`, read [transloco.md](references/transloco.md).

## Usage Rules

- Prefer the custom translation layer when the application must switch languages without rebuilding or redeploying.
- For Angular 20+ applications, use the maintained `@jsverse/transloco` packages, not the legacy `@ngneat/transloco` packages.
- Keep the default asset layout simple: one language file per locale in `assets/i18n/*.json`.
- Do not create a new dedicated `translations` library under `libs` for this pattern.
- Keep the Transloco runtime infrastructure in `libs/core/i18n`.
- Keep the lightweight custom `TranslatePipe` and `TranslateDirective` in `libs/shared/ui`.
- Keep `app.config.ts` focused on provider registration, not on defining translation infrastructure classes or config objects inline.
- Application and feature TypeScript code should import `TranslationsService` and provider helpers from `@project/core/i18n`.
- Application templates and standalone components should import `TranslatePipe` and `TranslateDirective` from `@project/shared/ui`.
- Do not import `TranslocoService`, `TranslocoPipe`, `TranslocoDirective`, or other `@jsverse/transloco` symbols outside `libs/core/i18n`.
- Keep the custom service, pipe, and directive lightweight and stable. If more translation features are needed, extend the custom layer instead of leaking third-party APIs into the rest of the workspace.
- Prefer stable, hierarchical keys such as `users.list.title` or `badgeLoginPage.header`.
- Keep app-specific copy in the application asset files, not inside generic libraries.
- Preserve SSR compatibility when reading browser APIs such as `localStorage` or `navigator.language`.