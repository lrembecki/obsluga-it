---
name: angular-lint
description: "Use when defining or updating ESLint rules, Nx architectural boundaries, layered feature libraries, integration-slice rules, SSR compliance checks, Angular-specific linting, approved UI wrapper restrictions, SonarQube quality gates, coverage enforcement, or CI lint workflows for PPG.GCSS.Angular."
---

# Angular Lint Standard

This skill defines the linting and code-quality standard for `PPG.GCSS.Angular`.

In this workspace, linting is not only about style. It is an enforcement layer for domain architecture, quality, and team contracts.

## Core Intent

Lint should:

- Enforce Nx domain and layer architecture.
- Prevent anti-patterns defined by the project instructions.
- Standardize Angular and TypeScript code.
- Support PR, CI, and SonarQube quality gates.
- Provide fast local feedback and useful autofix where possible.

## CRITICAL Architectural Enforcement

Lint should treat these as first-class architectural violations:

- business domains created outside `libs/features`
- `feature -> feature` imports
- `data-access -> feature` imports
- `shared` depending on `core` or `feature`
- app-wide singleton runtime or infrastructure placed in `shared`
- reusable stateless UI or helper code placed in `core`
- vendor UI imports outside approved `ui` layers

## Reference Map

- Read [strategy.md](references/strategy.md) for the overall linting model.
- Read [architectural-boundaries.md](references/architectural-boundaries.md) for Nx dependency rules and boundary enforcement.
- Read [angular-eslint.md](references/angular-eslint.md) for Angular, template, and TypeScript lint expectations.
- Read [service-architecture.md](references/service-architecture.md) for `data-access`, `store`, and `facade` separation rules.
- Read [ssr-compliance.md](references/ssr-compliance.md) for SSR-safe linting.
- Read [ui-governance.md](references/ui-governance.md) for approved `ui` layer restrictions.
- Read [quality-gates.md](references/quality-gates.md) for CI, PR, coverage, and SonarQube expectations.
- Read [nx-generators.md](references/nx-generators.md) for generator-aligned lint defaults.

## Usage Rules

- Use lint to automate architectural decisions before code review.
- Prefer enforced rules over informal team habits when a rule is stable enough.
- Keep lint aligned with the Angular, Nx, SSR, and domain-layer guidance of `PPG.GCSS.Angular`.
- Keep UI governance aligned with the `angular-primeng` skill so PrimeNG remains the primary third-party UI framework and raw `primeng/*` imports stay inside approved `ui` layers.