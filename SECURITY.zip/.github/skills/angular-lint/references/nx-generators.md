# Nx Generator Integration

## Purpose

Generators should help preserve the project standard rather than forcing developers to retrofit quality rules afterward.

## Expected Defaults

Generators and project scaffolding should align with:

- standalone Angular components
- OnPush by default
- strict typing
- lint-ready output

## Example Direction

```text
nx g @nx/angular:component --standalone
```

## Recommended Practice

- configure generators so new code starts close to the required standard
- avoid generating structures that violate SSR, slice rules, or UI governance
- add lint defaults automatically where the workspace tooling allows it

## Key Insight

The best enterprise lint setup does not only report problems. It prevents them during code generation and scaffolding.