# UI Governance Lint

## Purpose

UI governance lint protects the rule that third-party UI libraries are allowed only in approved `ui` layers.

## PrimeNG Restriction

PrimeNG must not be imported directly outside `libs/shared/ui` or a domain's own `libs/features/<domain>/src/lib/ui/` folder.

Example override for non-`ui` layers:

```json
{
  "overrides": [
    {
      "files": [
        "apps/**/*.ts",
        "libs/core/**/*.ts",
        "libs/shared/utils/**/*.ts",
        "libs/features/**/src/lib/feature/**/*.ts",
        "libs/features/**/src/lib/state/**/*.ts",
        "libs/features/**/src/lib/data-access/**/*.ts"
      ],
      "rules": {
        "no-restricted-imports": [
          "error",
          {
            "patterns": [
              {
                "group": ["primeng", "primeng/*"],
                "message": "Import PrimeNG only from libs/shared/ui or the owning feature ui layer. Consume wrappers everywhere else."
              }
            ]
          }
        ]
      }
    }
  ]
}
```

Allow raw PrimeNG imports only inside `libs/shared/ui/**` and `libs/features/**/src/lib/ui/**`.

## Review Fallback

If the workspace has not wired the lint override yet, treat the following as blocking review findings:

- raw `primeng` or `primeng/*` imports in app, feature, state, data-access, `core`, or `shared/utils` code
- new UI wrappers or bespoke controls created without checking the `angular-primeng` skill first
- wrapper code that re-exports or leaks raw vendor imports through a non-`ui` public API

## What This Enforces

- PrimeNG usage only inside approved `ui` layers
- reusable wrappers belong in `libs/shared/ui`
- feature and app code consume custom wrappers or domain presentational components instead of raw vendor components
- contributors check the `angular-primeng` skill before building a new wrapper or bespoke UI primitive
- UI governance remains consistent with the design system and domain-layer model