# Architectural Boundaries Lint

## Purpose

Architectural lint keeps the Nx dependency graph aligned with the domain-layer workspace standard.

## Mandatory Rule

Use `@nx/enforce-module-boundaries` to enforce dependency tags.

Treat the `core` versus `shared` split as critical. Use `type:feature` plus `scope:<domain>` tags for library boundaries, and use restricted-import rules to enforce `data-access`, `state`, `ui`, and `feature` folder directionality inside each feature library.

Example direction:

```json
{
  "rules": {
    "@nx/enforce-module-boundaries": [
      "error",
      {
        "depConstraints": [
          {
            "sourceTag": "type:app",
            "onlyDependOnLibsWithTags": ["type:core", "type:shared", "type:feature"]
          },
          {
            "sourceTag": "type:feature",
            "onlyDependOnLibsWithTags": ["type:feature", "type:shared", "type:core"]
          },
          {
            "sourceTag": "type:core",
            "onlyDependOnLibsWithTags": ["type:shared"]
          },
          {
            "sourceTag": "type:shared",
            "onlyDependOnLibsWithTags": ["type:shared"]
          }
        ]
      }
    ]
  }
}
```

Supplement module boundaries with restricted-import rules that block deep imports into `libs/features/**/src/lib/**` from outside the owning library. Cross-domain orchestration must go through an integration slice, and shared feature reuse must go through `@features/<domain>` public APIs.

## What This Must Prevent

- app-to-app dependencies
- library-to-app dependencies
- business domains created outside `libs/features`
- nested Nx libraries such as `libs/features/<domain>/data-access`
- a standalone `libs/design-system` library for shared tokens
- deep imports into another domain library's internal folders
- internal folder violations such as `data-access/ -> feature/` or `ui/ -> feature/`
- `shared` depending on `core` or `feature`
- app-wide singleton runtime or infrastructure living in `shared`
- reusable stateless UI or helper code living in `core`
- vendor UI imports outside approved `ui` layers
- architecture drift that breaks domain isolation

## Why It Matters

Without enforced module boundaries, the workspace will gradually lose domain isolation and layer discipline.