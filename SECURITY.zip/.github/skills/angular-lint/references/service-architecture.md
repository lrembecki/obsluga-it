# Feature Service Architecture Lint

## Purpose

Lint should enforce the separation between `data-access` and `state` responsibilities.

## Required Separation

- `libs/features/*/data-access` = HTTP, DTOs, mapping, and mock adapters
- `*.store.service.ts` = signal-based state in `libs/features/*/state`
- `*.facade.service.ts` = optional UI-facing orchestration in `libs/features/*/state`

## Key Rule

API services must not hold state.

Illustrative example:

```json
{
  "rules": {
    "no-restricted-syntax": [
      "error",
      {
        "selector": "ClassDeclaration[id.name=/.*ApiService$/] PropertyDefinition[key.name=/.*signal.*/]",
        "message": "API services must not contain state (signals)"
      }
    ]
  }
}
```

## Related Architectural Rules

- domain services must not use `providedIn: 'root'`
- stores expose readonly state, not public writable signals
- `data-access` must not import `feature`
- `feature` composes providers and orchestration instead of hiding business state in components

## Outcomes

- `data-access` remains transport-only
- `state` remains state-owner
- facades remain the optional public API for UI