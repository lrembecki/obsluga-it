# Angular, Template, and TypeScript Lint

## Angular Rules

Angular lint should enforce the project defaults:

- standalone components only
- OnPush change detection by default
- external component templates and styles for workspace-authored Angular components
- clean templates

Example:

```json
{
  "overrides": [
    {
      "files": ["*.ts"],
      "extends": ["plugin:@angular-eslint/recommended"],
      "rules": {
        "@angular-eslint/prefer-standalone": "error",
        "@angular-eslint/prefer-on-push-component-change-detection": "error",
        "@angular-eslint/component-max-inline-declarations": [
          "error",
          {
            "template": 0,
            "styles": 0
          }
        ]
      }
    }
  ]
}
```

Set `template` and `styles` to `0` so workspace-authored components must move markup and styles into co-located `.html` and `.scss` files via `templateUrl` and `styleUrl`.

## Template Rules

Template lint should enforce simple, performant templates.

Example:

```json
{
  "overrides": [
    {
      "files": ["*.html"],
      "extends": ["plugin:@angular-eslint/template/recommended"],
      "rules": {
        "@angular-eslint/template/no-call-expression": "error",
        "@angular-eslint/template/conditional-complexity": ["warn", { "maxComplexity": 3 }]
      }
    }
  ]
}
```

These rules help enforce the instruction that logic should not move into templates.

## TypeScript Rules

TypeScript lint should protect strict typing.

Example:

```json
{
  "rules": {
    "@typescript-eslint/no-explicit-any": "error",
    "@typescript-eslint/consistent-type-imports": "error",
    "@typescript-eslint/explicit-function-return-type": "warn"
  }
}
```

## Main Outcomes

- better maintainability
- stronger typing discipline
- less template logic
- no inline Angular component templates or styles in authored workspace components
- better fit with the Angular instruction set