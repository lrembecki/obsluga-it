# Lint Strategy

## Purpose

In `PPG.GCSS.Angular`, linting is an architecture and quality enforcement system, not only a code-style tool.

## Main Goals

- Enforce Nx, domain isolation, and vertical-slice layer boundaries.
- Prevent anti-patterns already forbidden by project instructions.
- Standardize Angular and TypeScript code.
- Support PR, CI, SonarQube, and coverage quality gates.
- Improve developer experience through fast feedback and targeted autofix.

## Enterprise Lint Layers

### Repository-Level Rules

- TypeScript strictness
- import rules
- naming conventions
- general code quality

### Architectural Lint

Architectural lint is mandatory. It must enforce:

- Nx dependency boundaries
- the `core` versus `shared` split
- `data-access`, `state`, `ui`, and `feature` layer separation
- no `feature -> feature` imports
- no business domains inside application folders
- approved vendor UI usage only inside `ui` layers

### Angular-Specific Lint

- standalone-only components
- OnPush by default
- signals-oriented patterns
- template safety and simplicity

### SSR Compliance Lint

- no unguarded `window` or `document`
- no browser-only APIs in SSR-sensitive code

### UI Governance Lint

- no direct PrimeNG imports outside approved `ui` libraries

## Key Insight

In an enterprise Angular workspace, lint acts as an automatic architect. If lint enforces domain and layer boundaries early, many structural problems disappear before code review starts.