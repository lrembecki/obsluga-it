# Quality Gates, CI, and SonarQube

## Local Workflow

Local development should use fast feedback loops:

- `nx lint <project>`
- `nx format:write`
- pre-commit hooks through `lint-staged` and `husky`

## PR Gate

Pull requests should fail when:

- lint fails
- coverage threshold fails
- SonarQube quality gate fails

## CI Example

```yaml
- script: npm run lint
- script: npm run test -- --coverage
- script: sonar-scanner
```

## SonarQube Integration

Recommended integration points:

- import ESLint results into SonarQube
- publish coverage through `lcov.info`

Example properties:

```text
sonar.typescript.lcov.reportPaths=coverage/lcov.info
sonar.eslint.reportPaths=eslint-report.json
```

## Typical Quality Gate Targets

- Bugs: `0`
- Vulnerabilities: `0`
- Coverage: `>= 80%`
- Code smells: below agreed threshold

## Coverage And Lint Synergy

Lint supports testability by enforcing:

- clearer service boundaries
- reduced template logic
- better architectural separation

This produces cleaner unit tests and more stable code.

## Governance Expectation

Definition of Done should include:

- lint passes
- SonarQube passes
- coverage threshold is met
- boundary rules remain intact
- UI still goes through approved `ui` layers
- service separation is preserved