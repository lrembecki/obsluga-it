# SSR Compliance Lint

## Purpose

SSR is mandatory in `PPG.GCSS.Angular`, so lint must protect server-safe code paths.

## Main Rule

Block unguarded browser globals such as `window` and `document`.

Example:

```json
{
  "rules": {
    "no-restricted-globals": [
      "error",
      {
        "name": "window",
        "message": "Use platform checks for SSR"
      },
      {
        "name": "document",
        "message": "Use platform checks for SSR"
      }
    ]
  }
}
```

## What To Prevent

- unguarded `window`
- unguarded `document`
- unguarded browser storage access
- browser-only assumptions in shared or core code that must run during SSR

## Expected Practice

- use platform checks
- isolate browser-only logic behind adapters or guarded branches
- keep SSR-sensitive code safe for server rendering and hydration