# Working With The Angular Design System

## Purpose

This workspace keeps shared design tokens, theme primitives, and reusable styling contracts inside approved `ui` libraries. Shared assets belong in `libs/shared/ui`, while domain-only styling contracts stay in the owning feature library under `libs/features/<domain>/src/lib/ui/`.

## Authoritative Token Source

Use `references/ppg-theme-tokens.scss` as the authoritative placeholder token file for this project.

- Use the full file content when a task needs the project's PPG theme token source.
- Do not copy only selected sections.
- Keep token names aligned across CSS custom properties, SCSS usage, and any TypeScript token wrappers.

## Placement Rules

- Put reusable shared tokens and styling primitives in `libs/shared/ui`.
- Put domain-specific styling contracts in `libs/features/<domain>/src/lib/ui/`.
- Keep tokens and styling contracts out of `core`, `data-access`, and `state`.
- Do not create a standalone `libs/design-system` library.

## Usage Rules

- Consume shared tokens instead of hardcoding colors, spacing, typography, radii, icon sizes, or z-index layers.
- Let applications and features consume styling primitives through approved `ui` libraries instead of creating parallel token systems.
- Keep `libs/shared/ui` stateless and free of app-wide runtime concerns.
- Update documentation or consuming wrappers when token contracts change in a meaningful way.

## Anti-Patterns

- Ad hoc values in app shells or feature code where shared tokens should be used.
- Shared business logic mixed into token or theme files.
- Vendor-specific styling contracts leaking into `feature`, `state`, or `data-access`.
- Partial copies of the project token file.