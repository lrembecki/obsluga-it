---
name: angular-design-system
description: "Use when creating or updating shared design tokens, theme primitives, CSS custom properties, theme files, or reusable UI styling contracts in PPG.GCSS.Angular."
---

# Angular Design System

This skill captures the design-system working standard for `PPG.GCSS.Angular`. Use it when the task involves shared tokens, theme files, CSS custom properties, styling primitives, or reusable UI contracts.

## Project Defaults

- Shared design tokens, theme primitives, and reusable styling contracts live in `libs/shared/ui`.
- Domain-specific styling contracts live in `libs/features/<domain>/src/lib/ui/`.
- There is no separate `libs/design-system` library in this workspace.
- `libs/shared/ui` remains stateless and must not depend on `libs/core`.
- PrimeNG styled-mode presets and tokens are the primary third-party theming surface.
- Reuse shared tokens instead of introducing ad hoc colors, spacing, typography, radius, or z-index values.

## Critical Token Rule

The file `references/ppg-theme-tokens.scss` is the authoritative placeholder token source for this project.

- Use the entire file content as-is when creating or updating the project's placeholder PPG theme token file.
- Do not shorten, normalize, rename, reorder, or partially copy the token set unless the task explicitly changes the token contract.
- Preserve the import note that explains the real-project replacement with `@pds/themes/theme-ppg/ppg-light.css`.

## Reference Map

- Read [references/design-system.md](references/design-system.md) for placement, dependency, and usage rules.
- Read [references/ppg-theme-tokens.scss](references/ppg-theme-tokens.scss) for the exact project token source.
- Read the `angular-primeng` skill for PrimeNG installation, theme preset, styled-mode, and Tailwind-specific guidance.

## Required Workflow

1. Decide whether the change belongs in `libs/shared/ui` or in a single feature library's `src/lib/ui/` folder.
2. Start from the shared token set in `references/ppg-theme-tokens.scss` when the task needs project theme tokens.
3. Check the PrimeNG theming guidance in `angular-primeng` before overriding vendor styles with ad hoc CSS.
3. Keep feature, state, and data-access code free of token definitions and vendor styling details.
4. Prefer backward-compatible token evolution and update consumers together when token contracts change.

## Anti-Patterns

- Creating a standalone `libs/design-system` library.
- Scattering raw color, spacing, or typography values across apps or features when a shared token exists.
- Putting reusable styling primitives in `core`.
- Importing vendor UI packages outside approved `ui` layers.
- Overriding PrimeNG component styling with broad CSS hacks when a preset or token-based approach would solve the problem.
- Creating a second project token source that drifts from `references/ppg-theme-tokens.scss`.