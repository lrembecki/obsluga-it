# PrimeNG With Tailwind

Official source: https://primeng.org/llms/pages/tailwind.md

## Official Baseline

- PrimeNG integrates with Tailwind through the official `tailwindcss-primeui` plugin.
- PrimeNG expects dark-mode selectors and CSS layer ordering to stay aligned with Tailwind when both are used together.
- PrimeNG recommends CSS layers over `!important` as the preferred override strategy.

## Workspace Rules

- Use Tailwind as a layout and utility layer around PrimeNG wrappers rather than replacing PrimeNG's component surface.
- Align PrimeNG `darkModeSelector` with the Tailwind dark variant when the application owns dark-mode toggling.
- Keep PrimeNG and Tailwind decisions centralized so wrappers do not invent their own layering or color-system assumptions.
- Prefer token-driven theming and utility classes before custom selector wars.

## Recommended Integration Decisions

- Confirm the Tailwind version and use the matching PrimeUI plugin setup.
- Decide CSS layer ordering before widespread component overrides land in the codebase.
- Use Tailwind utilities inside wrapper templates for layout, spacing, and responsive composition.
- Use PrimeNG theme tokens for component color and surface behavior whenever possible.