# PrimeNG Theming

Official source: https://primeng.org/llms/pages/styled.md

## Official Baseline

- PrimeNG styled mode is based on design tokens, a base layer, and a preset.
- Built-in presets include Aura, Material, Lara, and Nora.
- PrimeNG recommends token and preset customization over broad CSS overrides.
- Dark mode, CSS layers, prefixing, and scoped tokens are all first-class theme concerns.

## Workspace Rules

- Treat PrimeNG styled mode as the default theming path for third-party UI.
- Prefer preset customization and token overrides before ad hoc CSS selectors.
- Keep shared theme decisions and reusable token contracts in approved `ui` layers, primarily `libs/shared/ui`.
- Keep domain-only styling contracts in the owning feature `ui` folder.
- Avoid `::ng-deep` and large global overrides when a token or preset adjustment will solve the problem.

## Recommended Theme Decisions

- Choose a single initial preset and document why it fits the application.
- Decide whether dark mode follows system preference or an application-owned selector.
- Decide whether CSS layers are enabled so PrimeNG and Tailwind overrides remain predictable.
- Use component tokens only when a global semantic-token adjustment is insufficient.