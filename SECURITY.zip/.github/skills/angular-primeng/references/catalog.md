# PrimeNG Catalog

Official source catalog: https://primeng.org/ and https://primeng.org/assets/data/menu.json

Each component or utility listed in the PrimeNG `Components` menu is mirrored in this skill with a concise reference file named by the official route slug.

## Categories

- Form: `autocomplete`, `cascadeselect`, `checkbox`, `colorpicker`, `datepicker`, `editor`, `floatlabel`, `iconfield`, `iftalabel`, `inputgroup`, `inputmask`, `inputnumber`, `inputotp`, `inputtext`, `keyfilter`, `knob`, `listbox`, `multiselect`, `password`, `radiobutton`, `rating`, `select`, `selectbutton`, `slider`, `textarea`, `togglebutton`, `toggleswitch`, `treeselect`
- Button: `button`, `speeddial`, `splitbutton`
- Data: `dataview`, `orderlist`, `organizationchart`, `paginator`, `picklist`, `table`, `timeline`, `tree`, `treetable`, `virtualscroller`
- Panel: `accordion`, `card`, `divider`, `fieldset`, `panel`, `scrollpanel`, `splitter`, `stepper`, `tabs`, `toolbar`
- Overlay: `confirmdialog`, `confirmpopup`, `dialog`, `drawer`, `dynamicdialog`, `popover`, `tooltip`
- File: `fileupload`
- Menu: `breadcrumb`, `contextmenu`, `dock`, `menu`, `menubar`, `megamenu`, `panelmenu`, `tieredmenu`
- Chart: `chart`
- Messages: `message`, `toast`
- Media: `carousel`, `galleria`, `image`, `imagecompare`
- Misc: `animateonscroll`, `autofocus`, `avatar`, `badge`, `bind`, `blockui`, `chip`, `classnames`, `focustrap`, `fluid`, `inplace`, `metergroup`, `progressbar`, `progressspinner`, `ripple`, `scrolltop`, `skeleton`, `styleclass`, `tag`, `terminal`
- Utilities: `filterservice`

## Workspace Decision Rule

- Check the matching route reference in this folder before creating a new wrapper or bespoke UI primitive.
- If PrimeNG covers the requirement, build a wrapper in `libs/shared/ui` or the owning feature `ui` layer instead of inventing a new third-party dependency or ad hoc component surface.