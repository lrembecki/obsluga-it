# Popover

- PrimeNG category: Overlay
- Official docs: https://primeng.org/popover
- Import path: `primeng/popover`
- Check this before creating a custom wrapper or bespoke UI primitive.
- Use only behind wrappers in `libs/shared/ui` or the owning domain `src/lib/ui/` folder.
- Keep wrapper `.ts`, `.html`, and `.scss` files separate.
- Keep raw `primeng/*` imports out of app, feature, state, and data-access code.
