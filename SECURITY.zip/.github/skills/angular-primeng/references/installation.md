# PrimeNG Installation

Official source: https://primeng.org/llms/pages/installation.md

## Official Baseline

- Install `primeng` and `@primeuix/themes` from npm.
- Configure PrimeNG at application startup with `providePrimeNG`.
- PrimeNG documents Angular CLI as the recommended application setup path.
- Install only the component modules you use so the application stays lean.

## Workspace Rules

- PrimeNG is the primary third-party UI framework for this workspace.
- Keep PrimeNG bootstrap configuration in `app.config.ts` or another approved root boundary.
- Keep Angular component `.ts`, `.html`, and `.scss` files separate when you build PrimeNG wrappers.
- Do not import raw `primeng/*` modules outside approved `ui` layers.
- Verify the need against the `angular-primeng` component references before creating a new wrapper or custom presentational primitive.

## Recommended Starting Point

1. Install `primeng` and `@primeuix/themes`.
2. Add `providePrimeNG` to the application provider list.
3. Add `provideAnimationsAsync()` when the application needs animation support for PrimeNG interactions.
4. Pick an initial preset such as Aura and keep theme decisions centralized.
5. Build shared or domain wrappers before exposing PrimeNG surfaces to feature code.