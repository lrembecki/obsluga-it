# PrimeNG Configuration

Official source: https://primeng.org/llms/pages/configuration.md

## Official Baseline

- PrimeNG configuration starts with `providePrimeNG({ ... })` during application bootstrap.
- Common global settings include `theme`, `ripple`, translation values, overlay defaults, CSP nonce, z-index values, and filter mode options.
- PrimeNG also supports runtime configuration through the injected `PrimeNG` service.

## Workspace Rules

- Keep PrimeNG configuration at root composition boundaries such as `app.config.ts`, not in feature components.
- Put application-specific locale or translation bridging behind approved workspace services when the app already has a translation layer.
- Align overlay, z-index, and dark-mode settings with shell and design-system decisions instead of overriding them piecemeal in features.
- Keep raw PrimeNG configuration objects out of feature code unless the wrapper or app shell explicitly owns them.

## Recommended Configuration Areas

- Theme preset and theme options
- Ripple enablement
- Locale and translation wiring
- Overlay `appendTo` behavior
- Z-index defaults for dialog, menu, overlay, and tooltip layers
- CSP nonce when required by the host environment