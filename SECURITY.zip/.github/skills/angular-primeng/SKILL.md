---
name: angular-primeng
description: "Use when installing, configuring, reviewing, or wrapping PrimeNG in PPG.GCSS.Angular; choosing existing PrimeNG components before creating new UI wrappers; wiring providePrimeNG, styled-mode themes, or Tailwind integration; or mapping PrimeNG elements into shared/ui or domain ui wrapper components."
---

# Angular PrimeNG

Use this skill when a task touches PrimeNG setup, wrapper design, theming, Tailwind integration, or component selection in this workspace.

## Project Default

- PrimeNG is the primary third-party UI framework for Angular UI in this workspace.
- Consume PrimeNG only through wrapper components in `libs/shared/ui` or the owning domain's `src/lib/ui/` folder.
- Keep wrapper component `.ts`, `.html`, and `.scss` files separate. Do not use inline component templates or styles.
- Keep `providePrimeNG` setup in application bootstrap or other approved root boundaries, not scattered through feature code.
- Prefer PrimeNG styled-mode presets, design tokens, and Tailwind integration over broad vendor CSS overrides.
- Before creating a new wrapper component or bespoke UI primitive, check the matching PrimeNG reference under `references/` first.

## When To Use

Use this skill when you need to:

- install PrimeNG in a new or existing Angular application
- configure `providePrimeNG`, ripple, locale, z-index, overlays, or runtime configuration
- choose or customize a PrimeNG theme preset in styled mode
- integrate PrimeNG with Tailwind CSS
- decide whether a UI requirement is already covered by an existing PrimeNG component
- design reusable wrapper components in `libs/shared/ui` or domain-specific wrappers in a feature `ui` folder
- review or reduce raw `primeng/*` imports in non-`ui` layers

## Reference Map

- Read [installation.md](references/installation.md) for package installation and bootstrap setup.
- Read [configuration.md](references/configuration.md) for `providePrimeNG`, runtime settings, locale, overlays, and z-index guidance.
- Read [theming.md](references/theming.md) for styled-mode presets, design tokens, dark mode, and theme override rules.
- Read [tailwind.md](references/tailwind.md) for PrimeNG and Tailwind integration guidance.
- Read [catalog.md](references/catalog.md) for the official PrimeNG component catalog mirrored in this skill.
- Read component references named by official PrimeNG route slug such as [button.md](references/button.md), [select.md](references/select.md), [dialog.md](references/dialog.md), [table.md](references/table.md), and [toast.md](references/toast.md).

## Usage Rules

- Check PrimeNG references before creating a new wrapper or bespoke presentational primitive.
- Wrap PrimeNG components in `libs/shared/ui` when the surface is reusable across domains.
- Keep domain-specific PrimeNG wrappers in the owning feature library's `src/lib/ui/` folder.
- Export only the wrapper surface through the owning library public API; do not leak raw `primeng/*` imports across the workspace.
- Keep app-specific business mapping, validation, orchestration, and accessibility copy in your wrapper or feature code rather than modifying vendor internals.
- Use PrimeNG theme presets and token-based customization before reaching for ad hoc CSS overrides.
- Align PrimeNG dark mode and CSS layer decisions with the application's Tailwind and global styling setup.