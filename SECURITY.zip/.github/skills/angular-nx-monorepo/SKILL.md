---
name: angular-nx-monorepo
description: "Use when creating, reviewing, or reorganizing an Nx monorepo with single domain libraries under libs/features and internal data-access/state/ui/feature folders."
---

# Nx Monorepo

In this workspace, Nx organizes Angular code as thin applications plus one domain library per slice under `libs/features`.

## Authoritative Structure

```text
/apps
├── /<project-1>
└── /<project-2>

/libs
├── /core
├── /features
│   ├── /users
│   │   └── /src
│   │       ├── /index.ts
│   │       └── /lib
│   │           ├── /data-access
│   │           ├── /state
│   │           ├── /ui
│   │           └── /feature
│   ├── /permissions
│   └── /user-permissions
├── /shared
│   ├── /ui
│   └── /utils
└── /testing
```

Applications own runtime composition. Domains own business behavior.

## CRITICAL: Core Versus Shared

- `core` is app-wide singleton runtime and infrastructure, composed once at bootstrap or another root environment boundary.
- `shared` is stateless reusable UI and helper code. It must not depend on `core`.
- Reusable UI, pure helpers, and feature-agnostic presentation code do not belong in `core`.
- Global providers, interceptors, guards, config, app facades, and root stores do not belong in `shared`.

## Domain Model

Each domain library should separate these concerns internally:

- `data-access`: API communication, DTOs, mapping, mock adapters.
- `state`: stores, facades, and signal state.
- `ui`: presentational components.
- `feature`: routes, smart components, and orchestration.

If one workflow needs multiple domains, create an integration library under `libs/features/<integration-domain>` with the same internal folder layout.

## Dependency Rules

- `/apps/<project>` cannot depend on other `/apps/<project>`.
- `/apps/<project>` can depend on `@features/<domain>`, `core`, and `shared` libraries.
- `/libs` cannot depend on any `/apps/<project>`.
- A feature library can depend on `shared` and narrowly on `core`.
- Direct domain-to-domain imports should be limited to intentionally shared public APIs exported from `@features/<domain>`.
- `shared` cannot depend on `core` or `feature`.
- Third-party UI libraries must not be imported outside `libs/shared/ui` or a domain library's internal `ui` folder.
- PrimeNG is the primary approved third-party UI framework and should be wrapped in approved `ui` layers before use elsewhere.

Inside one feature library, keep folder directionality explicit:

- `feature/` can depend on `state/`, `data-access/`, and `ui/`
- `state/` can depend on `data-access/`
- `ui/` stays presentational and depends only on `shared`
- `data-access/` owns transport and mapping only

## Tags And Public APIs

Use project tags to express ownership and layers:

- `type:app`
- `type:feature`
- `type:core`
- `type:shared`
- `type:testing`
- `scope:<domain>`

Path aliases should point to `src/index.ts` only.

Example:

```text
"@features/users": ["libs/features/users/src/index.ts"]
```

## Decision Rules

- Put deployable applications in `apps/`.
- Put business domains in one library each under `libs/features`.
- Separate `data-access`, `state`, `ui`, and `feature` with folders inside `src/lib/`.
- Put reusable stateless UI, shared design tokens, and theme primitives in `libs/shared/ui`.
- Put reusable pure helpers in `libs/shared/utils`.
- Put app-wide singleton runtime and infrastructure in `libs/core`.
- Keep domain-specific styling contracts in the owning domain's `src/lib/ui/` folder.
- Check the `angular-primeng` skill before creating a new UI wrapper or custom presentational primitive.
- Put test-only mocks and helpers in `libs/testing`.
- Create an integration slice when one workflow touches multiple domains.

## Anti-Patterns

- Applications importing from other applications.
- Libraries importing from applications.
- Business domains created inside application folders.
- Creating nested Nx libraries such as `libs/features/<domain>/data-access`.
- Creating a standalone `libs/design-system` library for tokens that belong in approved `ui` libraries.
- Deep imports into another feature library's internal folders.
- Shared libraries depending on core or feature libraries.
- App-wide singleton runtime or infrastructure placed in `shared`.
- Reusable stateless UI or helper code placed in `core`.
- Third-party UI libraries imported outside approved `ui` layers.
- Expanding `core` with code that is not truly app-wide.
- Test-only mocks being imported by production code.

## Review Checklist

- The repository keeps deployable code in `apps/` and reusable code in `libs/`.
- Business domains live under one library at `libs/features/<domain>`.
- Each domain keeps `data-access`, `state`, `ui`, and `feature` folders inside `src/lib/`.
- Cross-domain workflows use integration slices.
- Core libraries hold only app-wide singleton runtime or infrastructure and are composed once at the root.
- Shared libraries stay stateless and do not depend on core or features.
- Cross-domain reuse goes through exported public APIs instead of deep imports.
- Third-party UI libraries are imported only inside approved `ui` libraries.
- PrimeNG is checked before a new wrapper or bespoke UI primitive is introduced.
- Testing code is restricted to `.spec.ts` usage.
- Public exports are declared in `src/index.ts`.
- Library boundaries improve clarity instead of increasing coupling.