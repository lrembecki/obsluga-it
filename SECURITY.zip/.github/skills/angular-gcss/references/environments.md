# Managing Angular Environments In `PPG.GCSS.Angular`

## Purpose

Environment files define deploy-specific runtime values for an application shell. In this workspace, each Angular application owns its environment files, while libraries stay environment-agnostic and receive configuration through `libs/core` providers or injection tokens.

## Core Rules

- Keep environment files in the owning app under `apps/<app-name>/src/environments/`.
- Add `apiBaseUrl` to the environment shape when the app needs a backend API endpoint.
- Treat environment files as public build-time configuration, not as a secret store.
- Never import `apps/<app-name>/src/environments/*` directly from `libs/features/*`, `libs/shared/*`, or other libraries.
- Pass environment-backed values from the application shell into `libs/core`, then consume them from `data-access` or other runtime infrastructure through DI.

## Recommended Structure

```text
apps/<app-name>/src/
├── environments/
│   ├── environment.model.ts
│   ├── environment.ts
│   ├── environment.development.ts
│   └── environment.staging.ts
└── app/
    └── app.config.ts
```

Use `environment.ts` as the default environment file for the app and add build-specific replacements for development, staging, or other deploy targets.

## Define The Environment Shape

Keep a single typed contract for app environment files.

```ts
// apps/<app-name>/src/environments/environment.model.ts
export interface AppEnvironment {
  readonly production: boolean;
  readonly apiBaseUrl: string;
}
```

## Define Environment Files

Keep the default file production-safe and override only what changes per build target.

```ts
// apps/<app-name>/src/environments/environment.ts
import type { AppEnvironment } from './environment.model';

export const environment: AppEnvironment = {
  production: true,
  apiBaseUrl: 'https://api.example.com',
};
```

```ts
// apps/<app-name>/src/environments/environment.development.ts
import type { AppEnvironment } from './environment.model';

export const environment: AppEnvironment = {
  production: false,
  apiBaseUrl: 'http://localhost:3000',
};
```

```ts
// apps/<app-name>/src/environments/environment.staging.ts
import type { AppEnvironment } from './environment.model';

export const environment: AppEnvironment = {
  production: false,
  apiBaseUrl: 'https://staging-api.example.com',
};
```

## Configure File Replacements

In Nx, keep file replacements on the owning application target.

```json
// apps/<app-name>/project.json
{
  "targets": {
    "build": {
      "executor": "@angular/build:application",
      "options": {
        "browser": "apps/<app-name>/src/main.ts"
      },
      "configurations": {
        "development": {
          "fileReplacements": [
            {
              "replace": "apps/<app-name>/src/environments/environment.ts",
              "with": "apps/<app-name>/src/environments/environment.development.ts"
            }
          ]
        },
        "staging": {
          "fileReplacements": [
            {
              "replace": "apps/<app-name>/src/environments/environment.ts",
              "with": "apps/<app-name>/src/environments/environment.staging.ts"
            }
          ]
        }
      }
    }
  }
}
```

If the app was scaffolded with Angular CLI support for environments, keep the generated replacements and extend them instead of inventing a second configuration path.

## Expose `apiBaseUrl` Through `libs/core`

The application shell should convert environment data into DI-friendly runtime configuration.

```ts
// libs/core/config/src/lib/api-base-url.token.ts
import { EnvironmentProviders, InjectionToken, makeEnvironmentProviders } from '@angular/core';

export const API_BASE_URL = new InjectionToken<string>('API_BASE_URL');

export function provideApiBaseUrl(apiBaseUrl: string): EnvironmentProviders {
  return makeEnvironmentProviders([
    {
      provide: API_BASE_URL,
      useValue: apiBaseUrl,
    },
  ]);
}
```

Export the token and provider helper through `libs/core/.../src/index.ts` so applications and libraries consume the public API only.

## Wire The Environment In The Application

The app shell owns the environment import and registers the provider once at bootstrap.

```ts
// apps/<app-name>/src/app/app.config.ts
import { ApplicationConfig, provideBrowserGlobalErrorListeners, provideZoneChangeDetection } from '@angular/core';
import { provideHttpClient, withFetch } from '@angular/common/http';
import { provideApiBaseUrl } from '@core/config';

import { environment } from '../environments/environment';

export const appConfig: ApplicationConfig = {
  providers: [
    provideBrowserGlobalErrorListeners(),
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideHttpClient(withFetch()),
    provideApiBaseUrl(environment.apiBaseUrl),
  ],
};
```

## Consume The Value In A Feature Data-Access Service

Feature libraries should consume `apiBaseUrl` through DI in `data-access`, not by importing environment files directly.

```ts
// libs/features/tenants/src/lib/data-access/services/tenants.api.service.ts
import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { API_BASE_URL } from '@core/config';

@Injectable()
export class TenantsApiService {
  private readonly http = inject(HttpClient);
  private readonly apiBaseUrl = inject(API_BASE_URL);

  getAll() {
    return this.http.get(`${this.apiBaseUrl}/tenants`);
  }
}
```

This keeps `apps/` responsible for deploy-specific configuration and keeps feature libraries portable and testable.

## Anti-Patterns

- Importing `environment` directly inside `libs/features/*`, `libs/shared/*`, or `libs/core/*` implementation code.
- Storing secrets, credentials, or private keys in environment files.
- Hardcoding API hosts inside `data-access` services.
- Spreading runtime configuration logic across multiple app bootstrap files instead of composing it once.
- Creating one shared environment file for every app in the monorepo instead of letting each app own its deploy-specific values.