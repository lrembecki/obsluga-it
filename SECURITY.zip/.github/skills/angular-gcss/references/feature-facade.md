# Creating `*.facade.service.ts`

## Purpose

Facade services live in the domain `state` layer. They provide an optional UI-facing API when pages or orchestration components need a stable public boundary over stores and domain actions.

## Location And Naming

- Place facade services in `libs/features/<domain>/src/lib/state/services/`.
- Name them as `*.facade.service.ts`.
- Export them from `@features/<domain>`.
- Register them from the owning `feature` layer or route providers.

## When To Create A Facade

Create a facade when:

- Multiple components or pages need the same public domain API.
- You want to hide store and orchestration details from the UI.
- The domain or integration slice benefits from a single UI-facing access point.

Skip the facade when the store already provides a clear enough public surface.

## Required Rules

- Facade services must not use `providedIn: 'root'`.
- Facades should not own low-level HTTP logic.
- Facades should expose readonly state and UI-facing commands.
- Facades should coordinate stores and domain actions, not duplicate them.

## Typical Shape

```ts
@Injectable()
export class UsersFacadeService {
    private readonly store = inject(UsersStoreService);

    readonly users = this.store.users;
    readonly loading = this.store.loading;

    loadUsers(): void {
        this.store.loadUsers();
    }
}
```

## Anti-Patterns

- `providedIn: 'root'` on domain facades.
- A facade that directly replaces the API service.
- Duplicating state already owned by the store.
- Exposing cross-domain orchestration that should be modeled as an integration slice.