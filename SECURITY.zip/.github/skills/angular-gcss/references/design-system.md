# Working With Shared UI Tokens And Styling Contracts

## Purpose

There is no separate `libs/design-system` library in this workspace standard. Shared design tokens, theme primitives, and styling contracts live in `libs/shared/ui`, while domain-specific styling contracts live in `libs/features/<domain>/src/lib/ui/`.

## What Belongs In Approved `ui` Libraries

- CSS custom properties.
- TypeScript token definitions.
- Theme primitives and theme configuration.
- Shared styling contracts consumed across the workspace.
- Domain-specific styling contracts that belong only to one feature's `ui/` folder.

## What Does Not Belong In Shared Tokens

- Feature business logic.
- Transport or state-layer code.
- PrimeNG wrapper components.
- App-specific styling shortcuts.
- Tokens that belong to one feature only should not be promoted into `libs/shared/ui`.

## Dependency Rules

- `libs/shared/ui` should remain stateless.
- Domain `ui/` folders may consume shared tokens from `libs/shared/ui`.
- Tokens and styling contracts do not belong in `core`, `data-access`, or `state`.

## How To Maintain It

- Add shared tokens in `libs/shared/ui` instead of scattering raw values across the codebase.
- Keep domain-only styling contracts in the owning domain's `ui/` folder.
- Prefer backward-compatible token evolution when possible.
- Update consuming UI wrappers when token contracts change.
- Document meaningful token or theme changes together with the implementation.

## How To Use It

- Consume tokens from `libs/shared/ui` or the owning domain's `ui/` folder instead of hardcoding colors, spacing, sizes, or typography values.
- Keep approved `ui` layers aligned with shared token contracts.
- Let applications and features consume styling primitives through approved `ui` libraries, not invent parallel token systems.

## Anti-Patterns

- Creating a standalone `libs/design-system` library for tokens that belong in approved `ui` layers.
- Putting reusable UI components outside approved `ui` layers.
- Adding business-driven styles that only make sense for one feature.
- Bypassing the design system with ad hoc values in app or feature code.