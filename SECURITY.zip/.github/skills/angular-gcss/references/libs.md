# Creating Libraries in `PPG.GCSS.Angular`

## Purpose

Libraries are the primary unit of organization in this workspace. Deployable code lives in `apps/`, while business domains, shared code, and runtime infrastructure live in `libs/`.

## Choose The Correct Library Area

- `libs/features/<domain>` for one business domain library.
- `libs/features/<domain>/src/lib/data-access` for API communication, DTOs, and mapping inside that library.
- `libs/features/<domain>/src/lib/state` for stores, facades, and signal state inside that library.
- `libs/features/<domain>/src/lib/ui` for domain-specific presentational components inside that library.
- `libs/features/<domain>/src/lib/feature` for routes, smart components, and composition inside that library.
- `libs/features/<integration-domain>` for cross-domain workflows using the same internal folder structure.
- `libs/shared/ui` for reusable stateless UI, shared design tokens, theme primitives, styling contracts, and approved vendor wrappers.
- `libs/shared/utils` for pure helpers and generic utilities.
- `libs/core` for app-wide singleton runtime and infrastructure.
- `libs/testing` for test-only helpers and mocks.

## Required Rules

- Libraries must not depend on applications.
- Do not create nested Nx libraries inside `libs/features/<domain>`.
- Do not create a standalone `libs/design-system` library for shared tokens.
- Export the public API only through `src/index.ts`.
- Point `tsconfig.base.json` path aliases to `src/index.ts`.
- Keep deep internal files private.
- Do not deep import another domain library's internal folders.
- Third-party UI libraries must not be imported outside approved `ui` libraries.

## Dependency Summary

- A feature library can depend on `shared` and narrowly on `core`.
- Other feature libraries may consume only the explicitly exported public API from `@features/<domain>`.
- Inside one feature library, `feature/` can depend on `state/`, `data-access/`, and `ui/`.
- Inside one feature library, `state/` can depend on `data-access/`.
- Inside one feature library, `ui/` can depend on `shared`.
- Inside one feature library, `data-access/` can depend on `core` and `shared`.
- `core` can depend on `shared`, approved third-party libraries, and testing.
- `shared` can depend on other `shared` libraries and testing.

## Typical Workflow

1. Pick the owning domain.
2. Create or reuse the single library at `libs/features/<domain>`.
3. Pick the correct internal folder inside `src/lib/`.
4. Keep the source under `src/lib/`.
5. Export public members from `src/index.ts` only.
6. Add or update the path alias as `@features/<domain>`.
7. Use an integration slice when one workflow needs multiple domains.

## Anti-Patterns

- Creating business domains inside the application shell.
- Creating nested Nx libraries such as `libs/features/<domain>/data-access`.
- Creating a standalone `libs/design-system` library instead of keeping tokens in approved `ui` libraries.
- Exporting deep internal files directly.
- Moving feature business logic into `core` or `shared` only for convenience.
- Moving app-wide singleton runtime into `shared`.
- Letting `shared` depend on `core`.
- Deep importing another domain library instead of using its public API or an integration slice.
- Importing PrimeNG directly in non-`ui` libraries.