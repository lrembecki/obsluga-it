# Working With `libs/core`

## Purpose

`libs/core` contains app-wide singleton runtime and infrastructure that are needed regardless of which route is active. Core code should support the whole application, not a single feature.

## What Belongs In `core`

- Global runtime services used across the app.
- DI helpers, provider factories, and injection tokens.
- Global constants and configuration helpers.
- HTTP interceptors, guards, resolvers, and global error-handling infrastructure.
- Global facades or signal stores that coordinate app-wide state.
- SSR-related abstractions or server-only adapters when they belong to a core concern.
- Minimal root shell or layout composition only when it is required to bootstrap the application.

## What Does Not Belong In `core`

- Stateless reusable UI components or presentation helpers.
- Pure helpers, directives, or pipes that can live in `shared`.
- Feature business logic.
- Feature-owned services.
- PrimeNG wrappers.
- Feature-specific components or page components.

## Dependency Rules

- `core` can depend on other `core` libraries, `shared`, approved third-party libraries, and testing code.
- `core` must not depend on `ui` or `features` libraries.

## Implementation Guidance

- Split `core` into small focused libraries instead of building one large utility bucket.
- Compose `core` once from bootstrap or another root application boundary.
- Export only through `src/index.ts`.
- For SSR-only code, keep server implementation under `src/lib/server/` and expose a dedicated server alias.
- Review new `core` additions carefully. If the code is not truly app-wide singleton runtime or infrastructure, keep it out of `core`.

## Anti-Patterns

- Putting convenience helpers in `core` just to make them easier to import.
- Moving reusable stateless UI or helper code into `core` for convenience.
- Hiding feature-specific business rules in a “generic” core service.
- Mixing browser-only runtime assumptions into server code without a boundary.