# Creating Applications in `PPG.GCSS.Angular`

## Purpose

Applications in this workspace are deployable runtime shells stored under `apps/`. They own bootstrap, SSR, layout, and route composition. They do not own business domains.

## When To Create A New Application

Create a new application when you need:

- A separately deployable Angular runtime.
- A distinct routing tree, SSR entry point, or runtime configuration.
- A separate ownership or release boundary.

Do not create a new application for code that should live in `libs/features`, `libs/shared`, or `libs/core`.

## Required Application Standards

- SSR with hydration is required.
- Standalone components are required.
- Use signals-first local state.
- Use OnPush by default.
- Keep business domains in `libs/features/<domain>/...`.
- Consume reusable stateless UI and shared tokens from `libs/shared/ui`.
- Keep vendor UI imports out of the application shell.

## Recommended Application Structure

```text
apps/<app-name>/src/
├── main.ts
├── main.server.ts
├── server.ts
└── app/
    ├── app.component.ts
    ├── app.config.ts
    ├── app.config.server.ts
    ├── app.routes.ts
    └── shell/
```

## Dependency Rules

- An application must not depend on another application.
- An application should compose `feature`, `core`, and `shared` libraries.
- Keep reusable logic in `libs/` and keep deployment-specific composition in `apps/`.

## Feature Integration

- Lazy load feature entry points from `@features/<domain>` where practical.
- Use integration slices such as `@features/user-permissions` when a route spans multiple domains.
- Keep app routes focused on composition, not business orchestration.

## Anti-Patterns

- Client-only application setup when SSR is required.
- Re-implementing shared UI or tokens inside an app.
- Placing business domains directly inside `apps/<app-name>/src/app/features`.
- Placing reusable app-wide infrastructure directly in `apps/` instead of `libs/core`.