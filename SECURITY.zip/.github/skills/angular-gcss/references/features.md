# Creating Features in `PPG.GCSS.Angular`

## Purpose

Each business domain is a vertical slice implemented as one library under `libs/features/<domain>`.

## Default Rule

Create new business domains under:

```text
libs/features/<domain>
```

Do not start new business features inside the application shell.

## Recommended Feature Structure

```text
libs/features/users/
└── src/
	├── index.ts
	└── lib/
		├── data-access/
		├── state/
		├── ui/
		└── feature/
```

## Layer Responsibilities

- `data-access`: API communication, DTOs, mapping, mock adapters.
- `state`: stores, facades, signal state, derived view state.
- `ui`: presentational components and domain-specific styling contracts.
- `feature`: smart components, routes, providers, and orchestration.

## Cross-Domain Strategy

If one workflow needs multiple domains, create an integration slice such as:

```text
libs/features/user-permissions/
└── src/
	└── lib/
		├── data-access/
		├── state/
		├── ui/
		└── feature/
```

Use integration slices instead of hiding orchestration inside an existing domain. When another domain needs reusable contracts or services, expose them from `@features/<domain>` and consume that public API only.

## Required References For A New Domain

When creating a new domain, read these references together:

- [feature-api.md](./feature-api.md) for `*.api.service.ts`
- [feature-store.md](./feature-store.md) for `*.store.service.ts`
- [feature-facade.md](./feature-facade.md) for `*.facade.service.ts`
- [design-system.md](./design-system.md) when the domain needs shared or domain-specific UI tokens and styling contracts
- [libs.md](./libs.md) when deciding whether code belongs in a shared or core library
- [app.md](./app.md) when wiring the domain into an application route tree

## Feature Creation Workflow

1. Create the domain library under `libs/features/<domain>`.
2. Add `data-access`, `state`, `ui`, and `feature` as internal folders under `src/lib/`.
3. Place DTOs, API services, and mappers in `data-access/`.
4. Place stores and facades in `state/`.
5. Place presentational components and domain-specific styling contracts in `ui/`.
6. Place routes, smart components, and provider composition in `feature/`.
7. Expose reusable members from `src/index.ts` for other features.
8. Create an integration slice when one workflow needs multiple domains.

## Anti-Patterns

- Building business domains inside `apps/<app-name>/src/app/features`.
- Creating nested Nx libraries such as `libs/features/<domain>/data-access`.
- Deep imports into another domain library's internal folders.
- Root-scoping domain services with `providedIn: 'root'`.
- Hiding cross-domain orchestration inside one domain instead of an integration slice.