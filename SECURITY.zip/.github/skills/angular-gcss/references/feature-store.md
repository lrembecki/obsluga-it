# Creating `*.store.service.ts`

## Purpose

Store services live in the domain `state` layer. They hold signal state, coordinate state transitions, and orchestrate calls to the owning domain's `data-access` library.

## Location And Naming

- Place store services in `libs/features/<domain>/src/lib/state/services/`.
- Name them as `*.store.service.ts`.
- Export them from `@features/<domain>`.
- Register them from the owning `feature` layer or route providers.

## Required Rules

- Store services must not use `providedIn: 'root'`.
- Store services are domain-scoped.
- Keep writable signals private.
- Expose readonly state, derived state, and commands to the UI.
- Orchestrate `data-access` calls and explicit state transitions in the store.

## Typical Shape

```ts
@Injectable()
export class UsersStoreService {
    private readonly api = inject(UsersApiService);
    private readonly _users = signal<UserVm[]>([]);
    private readonly _loading = signal(false);

    readonly users = this._users.asReadonly();
    readonly loading = this._loading.asReadonly();
    readonly hasUsers = computed(() => this.users().length > 0);

    loadUsers(): void {
        this._loading.set(true);
        // trigger API workflow and update state explicitly
    }
}
```

## Checklist

- State is kept in signals.
- Derived state uses `computed()`.
- Writable signals are not exposed directly to components.
- API calls and state transitions are explicit.
- Browser-only APIs are guarded when SSR is involved.

## Anti-Patterns

- `providedIn: 'root'` on domain stores.
- Public writable signals.
- Template logic replacing store-derived view state.
- Cross-domain orchestration that should live in an integration slice.