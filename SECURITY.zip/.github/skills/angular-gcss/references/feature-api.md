# Creating `*.api.service.ts`

## Purpose

API services live in the domain `data-access` layer. They own HTTP communication, DTOs, mapping, and temporary mock adapters for one domain.

## Location And Naming

- Place API services in `libs/features/<domain>/src/lib/data-access/services/`.
- Export them from `@features/<domain>`.
- Keep DTOs and mappers in the same `data-access/` folder.
- Register domain-scoped services from the owning `feature` layer or route providers.

## Required Rules

- Domain API services must not use `providedIn: 'root'`.
- API services are responsible for HTTP, DTOs, and mapping only.
- API services must not hold signal state or UI orchestration.
- DTO input and output should stay explicit.
- Components must not call low-level HTTP clients directly.
- If a temporary mock implementation exists, keep it in the same `data-access` layer behind the same public API.

## Typical Shape

```ts
@Injectable()
export class UsersApiService {
    private readonly http = inject(ApiService);

    getUsers() {
        return this.http.get<UserDto[]>('/api/users');
    }

    createUser(dto: CreateUserDto) {
        return this.http.post<UserDto>('/api/users', dto);
    }
}
```

## Checklist

- The service is domain-scoped, not root-scoped.
- The service only handles HTTP, DTOs, and mapping.
- No signals or UI state are stored here.
- Mapping to domain or view models does not leak into `ui` or templates.

## Anti-Patterns

- `providedIn: 'root'` on domain API services.
- Business orchestration hidden in a transport layer.
- Signals, writable state, or smart-component behavior inside the API service.
- `data-access` importing another domain's `feature` library.