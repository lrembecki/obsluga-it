---
name: angular-gcss
description: "Use when working on PPG.GCSS.Angular, creating single domain libraries under libs/features with internal data-access/state/ui/feature folders, defining exposed public APIs, integration slices, managing Angular application environments, or updating core, shared, and ui-token code under this project standard."
---

# Angular GCSS Standard

This skill captures the working standard for `PPG.GCSS.Angular`. Use it when creating or modifying applications, libraries, domains, or domain-scoped services in this workspace.

## Project Defaults

The default standard for `PPG.GCSS.Angular` is:

- Nx monorepo structure
- Vertical Slice Enterprise Architecture
- One domain library per slice under `libs/features/<domain>`
- Internal `data-access`, `state`, `ui`, and `feature` folders under `libs/features/<domain>/src/lib/`
- Integration slices for cross-domain workflows
- Thin applications in `apps/`
- Standalone components
- Separate `.ts`, `.html`, and `.scss` files for every Angular component
- SSR with hydration
- Signals-first local state
- OnPush change detection by default
- Schema-driven forms for business flows
- `libs/shared/ui` for reusable stateless UI, shared design tokens, styling contracts, and approved vendor wrappers
- PrimeNG as the primary third-party UI framework, consumed through wrapper components in approved `ui` layers
- `libs/shared/utils` for pure helpers and generic utilities
- `libs/core` for app-wide runtime and infrastructure
- App-owned environment files under `apps/<app-name>/src/environments/` for deploy-specific runtime values
- No standalone `libs/design-system`; shared tokens live in approved `ui` libraries

## CRITICAL: Core Versus Shared

- `core` is app-wide singleton runtime and infrastructure. Compose it once from root application boundaries.
- `shared` is stateless reusable UI, token, and helper code. It must not depend on `core`.
- Reusable vendor wrappers belong in approved `ui` layers, not in `core`.
- If the code explains how the app runs, it belongs in `core`.
- If it explains what many domains reuse without global state, it belongs in `shared`.

## Reference Map

- For a new application, read [app.md](references/app.md), [libs.md](references/libs.md), [design-system.md](references/design-system.md), and [features.md](references/features.md).
- For a new library or library placement decision, read [libs.md](references/libs.md).
- For `core` work, read [core.md](references/core.md).
- For application environment strategy, runtime configuration, and API endpoint setup, read [environments.md](references/environments.md).
- For a new domain, start with [features.md](references/features.md) and then read [feature-api.md](references/feature-api.md), [feature-store.md](references/feature-store.md), and [feature-facade.md](references/feature-facade.md) as needed.
- For PrimeNG installation, configuration, theming, Tailwind integration, or component selection, read the `angular-primeng` skill.

## Usage Rules

- Treat the files in `references/` as the task-specific expansion of the workspace standard.
- Choose the domain and layer before writing code.
- Keep environment files inside the owning application and pass environment-backed values into libraries through `core` DI tokens or provider helpers.
- Do not create nested Nx libraries under `libs/features/<domain>`.
- Keep Angular component metadata in `.ts` files and their templates and styles in separate co-located `.html` and `.scss` files.
- Check the `angular-primeng` skill before creating a new UI wrapper or custom control.
- Expose reusable domain APIs through `src/index.ts` only.
- Prefer the smallest change that preserves the existing architecture.
- Use integration slices when one workflow needs multiple domains.
- Keep new code aligned with `PPG.GCSS.Angular` naming, dependency rules, SSR requirements, and domain-layer conventions.