---
name: angular-test
description: "Use when creating or updating Jest unit tests, Playwright e2e tests, Nx test defaults, coverage thresholds, generic CI validation, or AI-assisted testing workflows aligned with layered feature libraries for PPG.GCSS.Angular."
---

# Angular Test Standard

This skill defines the testing and delivery-quality standard for `PPG.GCSS.Angular`.

Testing in this workspace is not an isolated activity. It works together with Nx workspace defaults, architectural boundaries, CI quality gates, and AI generation guidance.

## Core Intent

- Keep tests aligned with domain ownership and layer boundaries.
- Use the workspace defaults of Jest for unit tests and Playwright for e2e tests.
- Treat coverage, lint, and test execution as core delivery checks.
- Keep AI-generated tests compliant with SSR, standalone Angular patterns, and the approved `ui` layer model.

## Reference Map

- Read [strategy.md](references/strategy.md) for the overall testing model.
- Read [nx-workspace-defaults.md](references/nx-workspace-defaults.md) for the expected `nx.json` testing-related defaults.
- Read [project-tags-and-boundaries.md](references/project-tags-and-boundaries.md) for required project tags and dependency governance.
- Read [coverage-and-quality-gates.md](references/coverage-and-quality-gates.md) for coverage and generic CI validation guidance.
- Read [ai-test-generation.md](references/ai-test-generation.md) for AI-assisted test generation guidance.

## Usage Rules

- Keep tests close to the application, domain, or library that owns the behavior.
- Preserve Nx tags and module boundaries when adding new projects or new test targets.
- Keep coverage and CI validation aligned with the current workspace delivery standard.
- Keep generated or handwritten tests compatible with SSR and the approved `ui` layer model.