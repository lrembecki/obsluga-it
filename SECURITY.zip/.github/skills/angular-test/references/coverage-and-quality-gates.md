# Coverage And Quality Gates

## Goal

Keep coverage and CI validation explicit and repeatable.

Required checks:

- lint
- test
- coverage

## Recommended CI Pipeline

```yaml
steps:
  - script: npm ci
    displayName: Install dependencies

  - script: npx nx format:check
    displayName: Check formatting

  - script: npx nx run-many -t lint --all
    displayName: Lint

  - script: npx nx run-many -t test --all --code-coverage
    displayName: Unit tests with coverage

  - script: |
      if [ $(grep -o '"statements":[0-9.]*' coverage/coverage-summary.json | grep -o '[0-9.]*') \< 80 ]; then
        echo "Coverage below threshold"
        exit 1
      fi
    displayName: Enforce coverage
```

## Coverage Expectation

- Use `80%` statements coverage as the baseline threshold unless the workspace adopts a stricter target.
- Keep the CI threshold and local expectations aligned.

## Local Workflow

Before opening a pull request, developers should be able to run:

- `npx nx format:check`
- `npx nx run-many -t lint --all`
- `npx nx run-many -t test --all --code-coverage`

## Governance Intent

Coverage is not a vanity metric. It is a concrete validation signal that helps catch preventable regressions.

## Out Of Scope

Platform-specific pull request policies and external quality-gate integrations are intentionally excluded from this reference.