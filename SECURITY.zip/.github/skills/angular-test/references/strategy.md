# Testing Strategy

## Purpose

Testing in `PPG.GCSS.Angular` is part of the enforcement model for delivery quality.

The intended stack works across four layers:

- Nx workspace defaults define the expected tooling and targets.
- Automated tests verify application and library behavior.
- CI validation catches regressions before delivery.
- AI generation guidance keeps new tests aligned with architecture rules.

## Default Testing Stack

- Jest for unit tests in applications and libraries.
- Playwright for end-to-end tests.
- Nx targets for consistent local and CI execution.
- Coverage reporting in CI.

## What The Strategy Optimizes For

- Fast local feedback.
- Predictable CI validation.
- No cross-domain leakage in tests.
- Test code that respects the same architecture as production code.

## Testing Priorities

Test these areas first:

- Domain `data-access` services for HTTP request contracts and mapping behavior.
- Domain `state` stores for signal state transitions and commands.
- Domain facades for UI-facing orchestration when they exist.
- `feature` smart components and route composition for critical journeys.
- `ui` presentational components when they contain meaningful behavior.
- SSR-sensitive code paths that depend on guarded browser APIs.
- Critical end-to-end user journeys.

## Placement Rules

- Keep `*.spec.ts` close to the feature, page, component, or library being tested.
- Do not use tests to bypass public APIs or Nx boundaries.
- Do not let tests import another domain's `feature` layer directly.
- Extract shared test helpers only when they are reused broadly and the workspace has an approved shared testing location.

## Definition Of Done

A change is not complete until:

- tests pass
- coverage meets the agreed threshold
- lint passes
- architecture boundaries remain intact

## Out Of Scope

Platform-specific pull request policy and external quality-gate tooling are intentionally documented elsewhere.