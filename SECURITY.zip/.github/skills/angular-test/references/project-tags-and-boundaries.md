# Project Tags And Boundaries

## Purpose

Tests must preserve the same dependency boundaries as production code.

## Mandatory Project Tags

Every project should declare tags in `project.json`.

Example feature project:

```json
{
  "tags": ["type:feature", "scope:users"]
}
```

Example shared UI library:

```json
{
  "tags": ["type:shared"]
}
```

Example core library:

```json
{
  "tags": ["type:core"]
}
```

Example shared library:

```json
{
  "tags": ["type:shared"]
}
}
```

## Expected Dependency Constraints

Use Nx boundary enforcement in ESLint with this model:

```json
{
  "@nx/enforce-module-boundaries": [
    "error",
    {
      "depConstraints": [
        {
          "sourceTag": "type:app",
          "onlyDependOnLibsWithTags": [
            "type:core",
            "type:shared",
            "type:feature"
          ]
        },
        {
          "sourceTag": "type:feature",
          "onlyDependOnLibsWithTags": [
            "type:core",
            "type:shared",
            "type:feature"
          ]
        },
        {
          "sourceTag": "type:core",
          "onlyDependOnLibsWithTags": [
            "type:shared"
          ]
        },
        {
          "sourceTag": "type:shared",
          "onlyDependOnLibsWithTags": [
            "type:shared"
          ]
        }
      ]
    }
  ]
}
```

## Testing Implications

- Tests must import through the same public APIs as production code.
- Domain tests must not reach into another domain library's internal `src/lib/**` folders.
- `ui` tests must stay isolated from business orchestration.
- Cross-domain workflows should be tested through integration slices when that boundary exists.
- Core tests should preserve core purity and keep app-wide singleton runtime out of shared helpers.
- Shared test helpers must stay stateless and must not model `shared` code as depending on `core`.

## Review Standard

If a test only passes by bypassing boundaries, the test is wrong or the architecture needs to be reconsidered.