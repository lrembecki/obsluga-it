# Nx Workspace Defaults

## Purpose

The workspace should start with Nx defaults that make testing, linting, and CI predictable.

## Baseline `nx.json` Direction

Use a workspace configuration aligned with this model:

```json
{
  "$schema": "./node_modules/nx/schemas/nx-schema.json",
  "namedInputs": {
    "default": ["{projectRoot}/**/*"],
    "production": [
      "default",
      "!{projectRoot}/**/*.spec.ts",
      "!{projectRoot}/**/*.test.ts"
    ]
  },
  "targetDefaults": {
    "build": {
      "inputs": ["production", "^production"]
    },
    "lint": {
      "inputs": ["default", "{workspaceRoot}/.eslintrc.json"]
    },
    "test": {
      "inputs": ["default", "^production"]
    }
  },
  "workspaceLayout": {
    "appsDir": "apps",
    "libsDir": "libs"
  },
  "generators": {
    "@nx/angular:application": {
      "style": "scss",
      "linter": "eslint",
      "unitTestRunner": "jest",
      "e2eTestRunner": "playwright"
    },
    "@nx/angular:library": {
      "linter": "eslint",
      "unitTestRunner": "jest"
    }
  },
  "affected": {
    "defaultBase": "main"
  },
  "defaultProject": "app",
  "implicitDependencies": {},
  "tasksRunnerOptions": {
    "default": {
      "runner": "nx/tasks-runners/default",
      "options": {
        "cacheableOperations": ["build", "lint", "test"]
      }
    }
  }
}
```

## Why This Matters

- `production` excludes test files from production inputs.
- generator defaults keep new projects aligned with Jest and Playwright.
- cacheable operations speed up repeated validation in CI and locally.
- consistent target defaults reduce drift across projects.

## Testing Expectations

- Applications should use Jest for unit tests and Playwright for e2e tests.
- Libraries should use Jest for unit tests.
- New projects should inherit these defaults instead of defining custom runners unless there is a documented reason.