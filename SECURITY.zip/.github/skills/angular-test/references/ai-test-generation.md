# AI Test Generation Guidance

## Purpose

AI-generated tests must follow the same architecture and quality rules as handwritten tests.

## Mandatory Rules

### Architecture

- Always respect Nx dependency boundaries.
- Do not import across feature slices.
- Move shared test logic out of a feature only when it is truly reused and has an approved shared location.

### UI Rules

- Never import PrimeNG directly in generated test code.
- Use the components exposed by approved `ui` layers such as `libs/shared/ui` or the owning domain's `ui` library.

### Service Testing Rules

- API service tests should verify HTTP interaction and mapping behavior only.
- Store service tests should verify signal state transitions and commands.
- Facade service tests should verify UI-facing orchestration, not low-level transport details.

### Angular Rules

- Keep generated Angular test code compatible with standalone components.
- Preserve `ChangeDetectionStrategy.OnPush` assumptions when rendering or hosting components.
- Prefer signal-friendly test setups over patterns that assume mutable shared state.

### SSR Rules

- Do not rely on `window`, `document`, or `localStorage` without guards.
- Keep test doubles and helpers compatible with server-side rendering constraints.

### TypeScript Rules

- Avoid `any` in test fixtures and mocks.
- Keep generated test data typed and explicit.

## Output Expectations

When generating tests:

- place the test next to the owning feature, page, component, or library
- use `*.spec.ts` naming
- keep assertions focused on public behavior
- preserve feature service naming such as `*.api.service.ts`, `*.store.service.ts`, and `*.facade.service.ts`

## Strictly Forbidden Anti-Patterns

- direct PrimeNG imports
- cross-feature imports in tests
- tests that store application state inside API service stubs
- tests that depend on browser globals without SSR guards
- `any`-driven test setup that hides contract problems

## Key Insight

AI should not generate tests that merely pass. It should generate tests that reinforce the architecture and stay compatible with the workspace quality gates.