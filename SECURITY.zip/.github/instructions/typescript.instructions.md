---
description: "Use when creating or modifying TypeScript source files in Angular frontend, Nx libraries, domain slices, schema-driven forms, signals, core/shared boundaries, models, mappers, and shared-ui token integrations in this workspace."
name: "TypeScript Frontend And Shared Standards"
applyTo: "**/*.ts"
---

# TypeScript Frontend And Shared Standards

This workspace uses TypeScript inside an Nx-based Angular architecture built around one domain library per feature at `libs/features/<domain>`, with internal `src/lib/data-access`, `src/lib/state`, `src/lib/ui`, and `src/lib/feature` folders. Prefer the closest existing domain and folder pattern over generic utility extraction.

## Overview

- Keep TypeScript aligned with domain ownership and layer boundaries.
- Model business concepts explicitly with strict, readable types.
- Keep DTOs, view models, state contracts, and UI contracts in the layer that owns them.
- Treat mapping layers, schema definitions, and design tokens as first-class typed APIs.

## CRITICAL: Core Versus Shared

- `core` types and APIs describe app-wide singleton runtime, infrastructure, and root-scoped orchestration.
- `shared` types and APIs describe stateless reusable UI or helpers and must stay free of `core` dependencies.
- Keep pure helpers, reusable schema contracts, and shared UI contracts in `shared`.
- Keep app config, DI tokens, global stores, and root providers in `core`.
- Do not move feature-specific business rules into `core` or `shared` just to make imports easier.

## Required Workflow

- Confirm whether the target file belongs to `app`, `data-access`, `state`, `ui`, `feature`, `core`, or `shared` code before changing it.
- Confirm the owning domain before extracting or reusing types.
- Keep `data-access`, `state`, `ui`, and `feature` as internal folders inside one feature library. Do not split them into nested Nx libraries.
- For Angular component metadata, keep templates and styles in co-located `.html` and `.scss` files referenced by `templateUrl` and `styleUrl`.
- Check the `angular-primeng` skill before introducing a new wrapper component or custom UI surface.
- Reuse existing models, schema types, mappers, validators, tokens, and helpers before adding new abstractions.
- Keep types co-located with the slice or library that owns the behavior.
- Preserve Nx dependency constraints when extracting or moving TypeScript code.

## Dependency And Ownership Rules

- `app` code may depend on `feature`, `core`, and `shared`.
- A feature library may depend on `shared` and narrowly on `core` when app-wide infrastructure is required.
- Another feature library may consume only the public API exported from `@features/<domain>` when that surface is intentionally shared.
- `core` code may depend on `shared`.
- `shared` code may depend on other `shared` libraries.
- Inside one feature library, keep folder-level directionality: `feature/ -> state/, data-access/, ui/` and `state/ -> data-access/`.
- Do not deep import another domain's internal folders. Create an integration slice when orchestration spans multiple domains.

## Layer Ownership Rules

- `data-access` owns DTOs, API request and response models, transport mappers, and repository-style gateways.
- `state` owns signal state models, derived state contracts, stores, facades, and UI-facing commands.
- `ui` owns presentational inputs, outputs, and stateless component contracts.
- `feature` owns page composition, route models, provider composition, and orchestration contracts.
- `shared/ui` owns reusable stateless UI contracts, shared design tokens, and styling primitives used by multiple domains.
- `shared/utils` owns generic helpers and utility types with no business meaning.

## Type Safety Rules

- Never use `any`.
- Use `unknown` at external boundaries and narrow explicitly.
- Avoid `as` unless the value has already been validated or interop makes it unavoidable.
- Narrow early. Prefer discriminated unions and explicit result shapes over loosely typed state.
- Never use `var`. Always use `let` or `const`.
- Prefer `undefined` over `null` unless the domain explicitly requires `null`.
- Use `readonly` and immutable patterns by default.

## Domain Modeling Rules

- Do not leak DTOs directly into `ui` or component-facing APIs.
- Separate DTO, domain model, and view model concerns.
- Keep view models close to `state` or `feature`, not in `data-access`.
- Keep form schema types separate when they have different responsibilities from DTOs or view models.
- Make illegal states unrepresentable where practical.
- Keep models in the owning domain layer instead of creating global dumping files.

## Mapping And Boundaries

- Map API DTOs before they reach `ui` code, schema definitions, or component inputs.
- Keep transport mapping in `data-access`.
- Keep state-to-view-model mapping in `state` or `feature`.
- Prefer small, named mapping functions over inline object reshaping in components.
- Keep template-facing models simple, readonly, and purpose-built.

## Immutability And State

- Default to `readonly` and immutable updates.
- Do not mutate shared state in place.
- For Angular signals, expose readonly state where practical and update through controlled `state` services or component-local APIs.
- Components consume view models, not DTOs.
- Keep derived signal state typed explicitly.
- Keep transformation logic out of templates.

## Schema-Driven Forms

- Treat schema-driven forms as the default for business forms.
- Keep form schemas strongly typed and colocated with the owning feature or shared stateless library.
- Type field definitions, option sources, defaults, validation rules, and submitted values explicitly.
- Do not use untyped dynamic form configuration objects.
- Keep DTO-to-schema and schema-to-command mapping outside templates.

## UI Tokens And Styling Integration

- Reuse TypeScript tokens and styling contracts from `libs/shared/ui` or the owning domain's `ui/` folder instead of inventing local styling APIs.
- Treat PrimeNG as the default third-party UI framework and prefer wrappers around PrimeNG components over bespoke controls when the vendor surface already fits.
- Prefer focused, explicit props for shared or domain `ui` libraries over broad option bags.
- Keep vendor-specific types out of `feature`, `state`, and `data-access` code.
- Wrap or isolate third-party UI APIs inside approved `ui` layers before exposing them to feature code.
- Keep raw PrimeNG imports and types inside approved `ui` layers and map them to workspace-safe wrapper inputs and outputs before exposing them more broadly.

## Utility And Configuration Rules

- Reuse built-in utility types such as `Partial`, `Pick`, `Omit`, `Record`, and `ReturnType` before creating custom replacements.
- Do not reimplement standard utility types.
- Preserve strict typing assumptions. New TypeScript code should remain compatible with `strict`, `noImplicitAny`, `strictNullChecks`, and `noUncheckedIndexedAccess`.

## Review Checklist

- No `any`
- No unsafe `as`
- DTOs are not leaked to `ui`, form schemas, or component-facing APIs
- Types reflect the owning domain and layer
- Shared state is not mutated in place
- Schema-driven form contracts are typed explicitly
- Shared UI token contracts and approved `ui` contracts are reused instead of duplicated
- Angular component metadata points to external `.html` and `.scss` files when component code is authored in this workspace
- Nx domain and layer boundaries remain clear
