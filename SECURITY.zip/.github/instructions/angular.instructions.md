---
description: "Use when creating or modifying Angular applications, Nx feature libraries, standalone components, templates, routes, SSR, schema-driven forms, signals, and vertical-slice domain layers in this workspace."
name: "Angular Applications"
applyTo: "**/*.ts, **/*.html, **/*.scss, **/angular.json"
---

# Angular Applications

## Overview

`PPG.GCSS.Angular` uses an Nx-based Vertical Slice Enterprise Architecture.

Treat these as required defaults unless an existing area has a documented exception:

- Domain code lives in `libs/features`.
- Each business domain is a single library at `libs/features/<domain>`.
- Keep internal `data-access`, `state`, `ui`, and `feature` folders inside that library under `src/lib/`.
- Applications in `apps/` are thin composition shells.
- Standalone components are required.
- SSR with hydration is required for Angular applications.
- Signals are the default local state model.
- `ChangeDetectionStrategy.OnPush` is the default.
- Schema-driven forms are the default for business forms.
- Reusable stateless code lives in `libs/shared/ui` and `libs/shared/utils`.
- App-wide runtime and infrastructure live in `libs/core`.
- Shared design tokens, theme primitives, and foundational styling contracts live in approved `ui` libraries, primarily `libs/shared/ui`.
- PrimeNG is the primary third-party UI framework and is consumed through wrapper components in approved `ui` layers.
- Component classes, templates, and styles stay in separate co-located `.ts`, `.html`, and `.scss` files.

## Authoritative Architecture

The file-and-library architecture below is the authoritative workspace model:

```text
PPG.GCSS.Angular/
├── apps/
│   └── <app-name>/
│       └── src/
│           ├── main.ts
│           ├── main.server.ts
│           ├── server.ts
│           └── app/
│               ├── app.component.ts
│               ├── app.config.ts
│               ├── app.config.server.ts
│               ├── app.routes.ts
│               └── shell/
├── libs/
│   ├── core/
│   ├── features/
│   │   ├── users/
│   │   │   └── src/
│   │   │       ├── index.ts
│   │   │       └── lib/
│   │   │           ├── data-access/
│   │   │           ├── state/
│   │   │           ├── ui/
│   │   │           └── feature/
│   │   ├── permissions/
│   │   └── user-permissions/
│   ├── shared/
│   │   ├── ui/
│   │   └── utils/
│   └── testing/
└── docs/
```

Applications do not own business feature folders. Business behavior belongs in `libs/features`.

## Layer Responsibilities

Each feature library keeps these concerns separated internally under `src/lib/`:

- `data-access`: API communication, DTOs, mapping, mock adapters, repository-style gateways.
- `state`: stores, facades, signal state, derived state, and orchestration over `data-access`.
- `ui`: presentational components with no business orchestration.
- `feature`: smart components, routes, page composition, provider composition, and feature entry points.
- `shared/ui`: reusable stateless UI, shared design tokens, styling primitives, and approved third-party UI wrappers shared across domains.
- `shared/utils`: pure helpers, generic utilities, and reusable stateless contracts.
- `core`: app-wide singleton runtime, infrastructure, configuration, root guards, interceptors, tokens, and adapters.
- `testing`: test-only helpers and mocks.

## CRITICAL: Core Versus Shared

- `libs/core` is app-wide singleton runtime and infrastructure composed once at the root.
- `libs/shared/*` is stateless and reusable and must not depend on `libs/core`.
- Do not put reusable UI, pure helpers, schema primitives, or feature-agnostic presentation code into `core`.
- Do not put global config, interceptors, guards, app facades, root stores, or runtime adapters into `shared`.
- If the code explains how the app runs, it belongs in `core`.
- If the code explains what many domains reuse without global state, it belongs in `shared`.

## Dependency Rules

Treat these as strict architectural rules:

Allowed library-level dependencies:

- `app -> feature, core, shared`
- `feature library -> shared`
- `feature library -> core` only for real app-wide infrastructure or tokens
- `feature library -> feature library` only through another domain's public API when the reused surface is intentionally shared
- `core -> shared`
- `shared -> shared`

Required internal folder directionality inside one feature library:

- `feature/ -> state/, data-access/, ui/`
- `state/ -> data-access/`
- `ui/ -> shared`
- `data-access/ -> core, shared`
- `data-access/` owns transport and mapping only

Forbidden:

- deep imports into another feature library's `src/lib/**`
- `shared -> core`
- cross-domain orchestration hidden inside an existing domain instead of a dedicated integration slice
- vendor UI imports outside approved `ui` folders

## Cross-Domain Strategy

If one use case needs multiple domains, create a new integration library inside `libs/features`.

Example:

```text
libs/features/
├── users/
├── permissions/
└── user-permissions/
```

Each of these is one library. Keep `data-access`, `state`, `ui`, and `feature` as internal folders under `src/lib/`.

Use the integration slice for cross-domain orchestration. When another domain needs reusable contracts, facades, or services, expose them from `@features/<domain>` and consume that public API only.

## Required Workflow

- Identify the domain and the internal folder before creating or changing code.
- Default new business code to `libs/features/<domain>/...`, not to `apps/<app-name>/src/app/...`.
- Create or reuse one library per domain at `libs/features/<domain>`. Do not create nested libraries such as `libs/features/<domain>/data-access`.
- Keep internal `data-access`, `state`, `ui`, and `feature` folders inside `src/lib/`.
- Keep shared design tokens, theme primitives, and reusable styling contracts in `libs/shared/ui`.
- Keep domain-specific styling contracts inside the owning domain's `src/lib/ui/` folder.
- Keep every Angular component split into separate `.ts`, `.html`, and `.scss` files.
- Keep applications limited to bootstrap, SSR, shell, route composition, and global providers.
- Keep reusable stateless UI in `libs/shared/ui` and reusable helpers in `libs/shared/utils`.
- Keep app-wide runtime and infrastructure in `libs/core`.
- Export every library's public API through `src/index.ts` only.
- Point path aliases to `src/index.ts`.
- Prefer aliases such as `@features/users`, `@features/permissions`, `@shared/ui`, `@shared/utils`, and `@core/<name>`.
- Check the `angular-primeng` skill before creating a new wrapper component or bespoke UI primitive.
- When third-party UI is needed, use PrimeNG first and wrap it in `libs/shared/ui` if it is reusable across domains, or keep it inside the owning domain's `src/lib/ui/` folder when it is domain-specific.
- Never import vendor UI packages from folders outside approved `ui` layers.
- Preserve SSR compatibility and guard browser-only APIs.
- Read the `angular-lint` skill when changing architectural enforcement.

## Angular Implementation Rules

- Use standalone components only. Do not add new NgModules.
- Use `ChangeDetectionStrategy.OnPush` by default.
- Keep each component class, template, and stylesheet in separate co-located `.ts`, `.html`, and `.scss` files.
- Use `templateUrl` and `styleUrl` by default. Do not use inline `template` or `styles` metadata for workspace components.
- Use signals for local writable and derived state.
- Keep state in `src/lib/state/`, not in `data-access/` or `ui/`.
- Keep templates simple. Do not perform non-trivial mapping, filtering, or business logic in templates.
- Before building a new UI wrapper or custom control, check the `angular-primeng` skill and prefer an existing PrimeNG surface composed behind a wrapper component.
- Prefer native Angular control flow when the workspace version supports it.
- Use schema-driven forms by default for business forms.
- Keep DTO-to-domain and domain-to-view-model mapping outside templates.
- Guard `window`, `document`, `navigator`, `localStorage`, and `sessionStorage` for SSR.

## Service And Component Placement

- `libs/features/<domain>/src/lib/data-access/` owns `*.api.service.ts`, DTOs, adapters, mock adapters, and mapping.
- `libs/features/<domain>/src/lib/data-access/` should organize implementation under `models/`, `mappers/`, and `services/`.
- `libs/features/<domain>/src/lib/state/` owns `*.store.service.ts` and optional `*.facade.service.ts`.
- `libs/features/<domain>/src/lib/ui/` owns presentational components in `components/` only.
- `libs/features/<domain>/src/lib/feature/` owns `pages/`, `routes/`, smart or orchestration components, and `*-feature.providers.ts`.
- Domain-scoped services must not use `providedIn: 'root'`.
- Register domain-scoped services from the owning `src/lib/feature/` folder or route providers.
- Components must not call low-level HTTP clients directly.
- Reusable cross-domain APIs must be re-exported from `libs/features/<domain>/src/index.ts`; other features consume only that public surface.

Use this as the default domain shape:

```text
libs/features/users/
└── src/
      ├── index.ts
      └── lib/
            ├── data-access/
            │   ├── models/
            │   ├── mappers/
            │   └── services/
            │       └── users.api.service.ts
            ├── state/
            │   ├── models/
            │   └── services/
            │       ├── users.store.service.ts
            │       └── users.facade.service.ts
            ├── ui/
            │   └── components/
            └── feature/
                  ├── pages/
                  ├── routes/
                  └── users-feature.providers.ts
```

## Import Examples

Correct:

```ts
import { UsersApiService } from '@features/users';
import { PermissionsApiService } from '@features/permissions';
import { UserPermissionsFacadeService } from '@features/user-permissions';
```

Forbidden internal import:

```ts
import { UsersApiService } from '@features/users/src/lib/data-access/services/users.api.service';
```

## UI Libraries And Styling

- Treat `libs/shared/ui` as the default home for reusable shared UI and approved vendor wrappers.
- Treat `libs/shared/ui` as the default home for shared design tokens, theme primitives, and reusable styling contracts.
- Treat PrimeNG as the primary third-party UI framework for reusable Angular UI in this workspace.
- Keep domain-specific presentational components inside the owning domain's `src/lib/ui/` folder.
- Build thin wrapper components around PrimeNG in approved `ui` layers instead of scattering raw vendor components across feature code.
- Check the `angular-primeng` skill before creating a net-new wrapper or bespoke presentational primitive.
- Reuse `libs/shared/ui` tokens and the owning domain's `src/lib/ui/` styling contracts instead of inventing ad hoc values.
- Do not import third-party UI libraries outside `libs/shared/ui` or `libs/features/<domain>/src/lib/ui/`.
- Keep vendor-specific markup out of `feature/`, `state/`, and `data-access/` folders.

## Routing And Loading

- SSR with hydration is required for user-facing Angular apps.
- Keep route definitions in the owning `src/lib/feature/routes/` folder.
- Lazy load feature routes where practical.
- Keep application routes focused on composition of `feature` entry points.
- Keep browser-only APIs behind platform checks or dedicated adapters.

## Linting And Quality Rules

- Treat linting as architectural enforcement, not only as style checking.
- Enforce domain isolation, layer boundaries, and restricted imports through Nx and ESLint rules.
- Block direct `feature -> feature` imports.
- Block vendor UI imports outside approved `ui` layers.
- Keep PR and CI quality gates wired to lint, tests, and coverage.

## Anti-Patterns

- Putting business domains under `apps/<app-name>/src/app/features`.
- Creating nested Nx libraries such as `libs/features/<domain>/data-access`, `state`, `ui`, or `feature`.
- Creating a standalone `libs/design-system` library for tokens that belong in approved `ui` libraries.
- Deep imports across domain libraries.
- Shared business logic hidden in `libs/shared`.
- Monolithic `data-access` libraries that mix unrelated domains.
- Reusable stateless UI or helpers placed in `core`.
- App-wide singleton runtime or infrastructure placed in `shared`.
- Vendor UI imports outside approved `ui` folders.
- Creating a new custom wrapper or bespoke UI primitive before checking `angular-primeng` and existing PrimeNG-based wrappers.
- Client-only setup when SSR is required.
- Unguarded browser-only API usage.
- Complex mapping or business logic in templates.

## Review Checklist

- Domain behavior lives under `libs/features/<domain>/...`.
- Each domain is one library under `libs/features/<domain>`.
- Applications stay thin and do not own business slices.
- Each domain keeps `data-access`, `state`, `ui`, and `feature` concerns separated inside `src/lib/`.
- Cross-domain orchestration uses a dedicated integration slice.
- Reusable cross-domain APIs are exported from `src/index.ts`; no deep imports are used.
- `shared` stays stateless and does not depend on `core`.
- `core` contains only app-wide singleton runtime or infrastructure.
- `data-access` owns HTTP, DTOs, and mapping.
- `state` owns signals, stores, and optional facades.
- `ui` stays presentational.
- `feature` owns smart components, routes, and composition.
- Third-party UI imports stay inside approved `ui` layers.
- PrimeNG is evaluated before introducing a new wrapper or bespoke UI primitive.
- Component classes, templates, and styles stay in separate `.ts`, `.html`, and `.scss` files.
- Components are standalone and use OnPush by default.
- SSR and hydration remain enabled.
- Browser-only APIs are guarded.
- Public APIs are exported through `src/index.ts`.