---
description: "Use when working in an Nx monorepo, creating or moving apps and libraries, defining dependency boundaries, or enforcing domain-layered feature libraries in this workspace."
name: "Nx Monorepo Boundaries"
applyTo: "**"
---

# Nx Monorepo Boundaries

Use these rules when the workspace follows Nx. In this repository, the authoritative Nx model is single domain libraries under `libs/features/<domain>`, each with internal `src/lib/data-access`, `src/lib/state`, `src/lib/ui`, and `src/lib/feature` folders.

## Core Rules

- Keep deployable applications in `apps/`.
- Keep reusable implementation in `libs/`.
- Do not allow one app in `apps/` to depend on another app.
- Do not allow any library in `libs/` to depend on an app.
- Do not create nested Nx libraries under an existing `libs/features/<domain>` folder.
- Export each library's public API through `src/index.ts`.
- Point `tsconfig.base.json` path aliases to the library's `src/index.ts`.

## Authoritative Library Placement

- `libs/features/<domain>`
- `libs/features/<integration-domain>` for cross-domain orchestration
- `libs/shared/ui`
- `libs/shared/utils`
- `libs/core`
- `libs/testing`

Inside each feature library, keep `data-access`, `state`, `ui`, and `feature` as internal folders under `src/lib/`, not as separate Nx libraries.

There is no separate `libs/design-system`; shared tokens and styling primitives live in `libs/shared/ui`, or in a domain's own `src/lib/ui/` when they are domain-specific.

Do not place business domains inside `apps/<app-name>/src/app/features`.

## CRITICAL: Core Versus Shared

- `core` means app-wide singleton runtime and infrastructure composed once at the root.
- `shared` means stateless reusable UI and helpers with no dependency on `core`.
- Do not put reusable UI, pure helpers, or feature-agnostic presentation code into `core`.
- Do not put global providers, interceptors, guards, app facades, root stores, or runtime configuration into `shared`.

## Dependency Rules

- `apps` should typically depend on `feature`, `core`, and `shared` libraries.
- `feature` libraries can depend on `shared` and narrowly on `core` when app-wide infrastructure is required.
- `feature` libraries may consume another feature library only through that library's public API when the reused surface is intentionally shared.
- `core` can depend on `shared`, approved third-party runtime libraries, and the global testing library.
- `shared` can depend on other `shared` libraries and the global testing library.
- `testing` code must be used only in `.spec.ts` files.
- `shared` must not depend on `core` or `feature` libraries.
- Third-party UI libraries must not be imported outside `libs/shared/ui` or a domain's own `libs/features/<domain>/src/lib/ui/` folder.
- PrimeNG is the primary approved third-party UI framework and should be evaluated before any new wrapper or bespoke UI primitive is introduced.

Inside one feature library, keep folder-level directionality explicit:

- `feature/` may depend on `state/`, `data-access/`, and `ui/`
- `state/` may depend on `data-access/`
- `ui/` stays presentational and may depend on `shared`
- `data-access/` owns transport and mapping and may depend on `core` and `shared`

## Integration Slice Rules

- If one workflow needs multiple domains, create an integration slice in `libs/features/<integration-domain>`.
- Do not hide cross-domain orchestration inside an existing domain.
- Integration slices may compose public APIs from other feature libraries, but must not import another library's internal folders.

## Tagging Guidance

Use project tags that reflect both ownership and layer:

- `type:app`
- `type:feature`
- `type:core`
- `type:shared`
- `type:testing`
- `scope:<domain>`

Use `type:feature` plus `scope:<domain>` to track ownership. Internal `data-access`, `state`, `ui`, and `feature` boundaries are folder conventions inside a single feature library.

## Implementation Guidance

- Keep applications thin. Their job is composition, not business ownership.
- Keep each domain isolated and cohesive as one feature library.
- Separate `data-access`, `state`, `ui`, and `feature` with folders inside `src/lib/`.
- Keep Angular component `.ts`, `.html`, and `.scss` files co-located and separate for every wrapper or presentational component.
- Move generic reusable presentation code, shared tokens, and theme primitives to `libs/shared/ui`.
- Move generic pure helpers to `libs/shared/utils`.
- Keep domain-specific styling contracts in the owning domain's `src/lib/ui/` folder.
- Check the `angular-primeng` skill before creating a new UI wrapper or custom presentational primitive.
- Do not expand `core` unless the code is truly app-wide runtime infrastructure.
- Compose `core` once from root application boundaries only.
- Keep deep internal files private and import through the public API only.

## Review Checklist

- Apps do not depend on other apps.
- Libraries do not depend on apps.
- Business domains live under one library at `libs/features/<domain>`.
- Each domain keeps `data-access`, `state`, `ui`, and `feature` folders inside `src/lib/`.
- Cross-domain flows use integration slices.
- Cross-domain reuse goes through exported public APIs only.
- `shared` libraries do not depend on `core` or `feature` libraries.
- Reusable stateless UI or helper code is not placed in `core`.
- Global runtime or singleton logic is not placed in `shared`.
- Third-party UI libraries are imported only inside approved `ui` libraries.
- PrimeNG is checked before adding a new wrapper or bespoke UI primitive.
- Testing code is not imported by production code.
- Public exports are declared in `src/index.ts`.
- Path aliases point to `src/index.ts`.