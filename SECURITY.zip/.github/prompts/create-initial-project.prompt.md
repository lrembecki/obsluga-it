name: "Create Initial Project"
description: "Scaffold the initial PPG.GCSS.Angular Nx workspace with a multi-domain shell, environments, linting, core/shared foundations, translations, and feature slices."
argument-hint: "Optional overrides such as app name, route prefix, domain names, or feature scope"
agent: "agent"
---

Create or extend the current workspace in place to establish the initial `PPG.GCSS.Angular` application with two top-level domains: `admin` and `catalog`.

Use these files as the authoritative rules for the implementation:

- [Angular Applications](../instructions/angular.instructions.md)
- [Nx Monorepo Boundaries](../instructions/nx.instructions.md)
- [TypeScript Frontend And Shared Standards](../instructions/typescript.instructions.md)
- [angular-gcss skill](../skills/angular-gcss/SKILL.md)
- [angular-translations skill](../skills/angular-translations/SKILL.md)
- [angular-lint skill](../skills/angular-lint/SKILL.md)
- [angular-new-app skill](../skills/angular-new-app/SKILL.md)

Execution rules:

- Save all generated code, configuration, translation content, mock data, and documentation in English.
- Inspect the current workspace first. If Angular or Nx scaffolding already exists, extend it instead of recreating it.
- If the workspace is not yet an Angular Nx workspace, scaffold it in place with SSR, hydration, standalone components, SCSS, and ESLint.
- Keep the application thin under `apps/` and keep business code in one library per domain under `libs/features/<domain>/src/lib/{data-access,state,ui,feature}`.
- Create an application shell with a dark sidebar and a light navbar.
- Use the light navbar to switch between the top-level domains (`admin`, `catalog`).
- Use the dark sidebar to switch between the pages that belong to the currently selected domain.
- Treat `tenant-user-permissions` as an integration slice. Do not hide its workflow inside one domain library or solve it with deep imports across domains.
- Keep `core` for app-wide singleton runtime and infrastructure only.
- Keep `shared` stateless and free of `core` dependencies.
- Keep PrimeNG imports inside approved `ui` layers and shared reusable form or UI wrappers.
- Domain `*.api.service.ts`, `*.store.service.ts`, and `*.facade.service.ts` must be domain-scoped and must not use `providedIn: 'root'`.
- Export public APIs through `src/index.ts` only and keep path aliases aligned.
- Generate representative dummy data for all requested views, forms, tables, and relationships.
- Support two application environments: `development` for local work and `production` for production builds.
- Do not stop at analysis or planning. Implement the changes, validate them, and then summarize the outcome.

Deliver the work in this order.

1. Base workspace and shell

- Create the initial Angular application named `PPG.GCSS.Angular`.
- Keep the app shell under `apps/` and compose feature routes from the application route tree.
- Add `admin` and `catalog` route areas that host the requested feature routes.
- Implement the shell layout with a dark sidebar and a light navbar.
- Make domain switching happen in the navbar and page switching happen in the sidebar for the currently selected domain.
- Show these domain entries in the navbar: `Admin`, `Catalog`.
- Show these `admin` sidebar pages: `Users`, `Tenants`, `Permissions`, `Tenant-User Permission Management`.
- Show these `catalog` sidebar pages: `Products`, `Batches`, `Customers`.
- Ensure SSR with hydration remains enabled.
- Add and wire `development` and `production` environment configuration for local serve and production build flows.

2. Linting and architectural enforcement

- Configure ESLint and Nx boundary rules to enforce the one-library-per-domain architecture.
- Enforce or document restrictions for deep imports across feature libraries, internal folder directionality, `shared -> core`, and vendor UI imports outside approved `ui` folders.
- Ensure the lint setup is practical for local development and CI.

3. Core and shared UI foundations

- Create the foundational libraries required for this template instead of speculative extras.
- Ensure `libs/core` contains the app-wide runtime, infrastructure, and environment configuration access needed by the app.
- Create `libs/shared/ui` for reusable stateless UI, shared design tokens, theme primitives, styling contracts, shell navigation primitives, and PrimeNG wrappers.
- Create `libs/shared/forms` for stateless schema-driven form primitives built on the shared UI controls.
- Create `libs/shared/utils` for generic helpers when needed.
- Keep `shared/forms` and `shared/ui` reusable and domain-agnostic.

4. Translations

- Implement the custom translation layer described by the workspace guidance.
- Keep runtime translation infrastructure in `libs/core/i18n`.
- Expose template translation primitives from `libs/shared/ui`.
- Store translation assets under the application `src/assets/i18n/*.json`.
- Add enough seed translation content for the shell, both domain navigations, and the requested feature pages.
- Do not leak `@jsverse/transloco` imports or types outside the translation infrastructure.

5. Shared UI and schema-driven forms

- In `libs/shared/ui`, create reusable shell components or wrappers for the layout, navigation, `buttons`, `inputs`, `select`, `dropdowns`, and `multiselect`.
- In `libs/shared/forms`, create the schema-driven form primitives needed for the tenant create or edit flow.
- Reuse shared UI token contracts instead of hard-coded ad hoc values.

6. Users domain

- Create the `users` feature library with internal `data-access`, `state`, `ui`, and `feature` folders.
- Keep state as an array of `UserVM[]`.
- Create a mocked API service that returns about 1000 records.
- Add a facade over the store.
- Use a `UserVM` model with:
  - `userId`
  - `email`
- Create a page under `admin/users` that lists users.
- Allow navigation from the users list to the related tenant details without inventing undeclared fields on `UserVM`; derive relationships from the appropriate tenant or assignment data.
- Provide representative dummy user data for demo purposes.

7. Tenants domain

- Create the `tenants` feature library with internal `data-access`, `state`, `ui`, and `feature` folders.
- Keep state as an array of `TenantVM[]`.
- Create a mocked API service that returns about 1000 records.
- Add a facade over the store.
- Create a `TenantVM` model with:
  - `tenantID`
  - `name`
  - `slug`
- Create a `TenantDTO` model with:
  - `tenantID`
  - `name`
  - `slug`
  - assigned users (`UserVM[]`)
- If identifier casing is normalized in code, use explicit mapping and keep the public contract consistent.
- Create a list page under `admin/tenants`.
- Create a create or edit page under `admin/tenants/create` and `admin/tenants/:tenantId`.
- The tenant form must support updating the tenant name and assigning or removing users.
- Implement the tenant form as a schema-driven form using the shared form library.
- Provide representative dummy tenant data for demo purposes.

8. Permissions domain

- Create the `permissions` feature library with internal `data-access`, `state`, `ui`, and `feature` folders.
- Keep state as an array of `PermissionVM[]`.
- Create a mocked API service that returns about 1000 records representing permissions for mock pages.
- Add a facade if it improves the public state API.
- Use a `PermissionVM` model with:
  - `permissionId`
  - `name`
  - `description`
- Create a page under `admin/permissions` that lists permissions.

9. Tenant-user-permissions integration slice

- Create the `tenant-user-permissions` integration slice under `libs/features`.
- Keep state as an array of `TenantUserPermissionVM[]`.
- Create a mocked API service that returns about 1000 relationship records built from the generated tenants, users, and permissions.
- Add a store and facade that support assigning users to tenants and permissions for a selected user and tenant.
- Define a minimal explicit `TenantUserPermissionVM` model that captures the association clearly and supports the UI and navigation flows.
- Create a page under `admin/tenant-user-permissions` for the `Tenant-User Permission Management` workflow.
- Reuse this slice for cross-domain orchestration instead of deep-importing or embedding the workflow inside one domain library.

10. Customers domain

- Create the `customers` feature library with internal `data-access`, `state`, `ui`, and `feature` folders.
- Keep state as an array of `CustomerVM[]`.
- Create a mocked API service that returns representative customer records.
- Add a facade if it improves the public state API.
- Use a `CustomerVM` model with:
  - `name`
- If an internal identifier is needed, add it explicitly and map it cleanly without changing the requested UI contract.
- Create a page under `catalog/customers` that lists customers.
- Provide representative dummy customer data for demo purposes.

11. Products domain

- Create the `products` feature library with internal `data-access`, `state`, `ui`, and `feature` folders.
- Keep state as an array of `ProductVM[]`.
- Create a mocked API service that returns representative product records.
- Add a facade if it improves the public state API.
- Use a `ProductVM` model with:
  - `code`
  - `name`
  - `slug`
  - `colorRgba`
  - `customer`
- If an internal identifier or nested customer reference is needed, add it explicitly and map it cleanly while keeping the requested product contract readable.
- Create a page under `catalog/products` that lists products.
- Provide representative dummy product data and relate each product to a generated customer.

12. Batches domain

- Create the `batches` feature library with internal `data-access`, `state`, `ui`, and `feature` folders.
- Keep state as an array of `BatchVM[]`.
- Create a mocked API service that returns representative batch records.
- Add a facade if it improves the public state API.
- Use a `BatchVM` model with:
  - `lot`
  - `product`
  - `expirationDate`
- Create a page under `catalog/batches` that lists batches.
- Provide representative dummy batch data and relate each batch to a generated product.

13. Representative dummy data

- Generate consistent dummy data across `admin` and `catalog`.
- Keep relationships coherent for users, tenants, permissions, products, batches, and customers.
- Size the datasets to make tables, navigation, filters, and forms feel representative without making local demo usage impractical.

14. Validation

- Wire the `admin` and `catalog` routes into the application.
- Verify that navbar domain switching and sidebar page switching work as intended.
- Run the smallest practical lint, test, and build or typecheck commands for the created or changed projects and the relevant environment configurations.
- Fix issues introduced by the work.

When you finish, respond with:

1. What was created
2. Validation run and its result
3. Assumptions, gaps, or follow-up work