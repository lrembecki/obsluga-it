---
name: "Review Nx Monorepo"
description: "Review an Nx monorepo for apps/libs boundaries, critical core/shared placement, dependency rules, and public API organization."
argument-hint: "What should be reviewed? Example: current workspace, a feature group, dependency boundaries, or a refactor plan"
agent: "Nx Monorepo Reviewer"
---

Review the Nx monorepo using the guidance in [angular-nx-monorepo skill](../skills/angular-nx-monorepo/SKILL.md) and [Nx instructions](../instructions/nx.instructions.md).

Treat the following as CRITICAL while reviewing:

- `core` is app-wide singleton runtime or infrastructure composed once at the root.
- `shared` is stateless reusable code and must not depend on `core`.
- Reusable UI or pure helpers in `core` and global runtime in `shared` are architectural findings, not style issues.

Focus on:

- `apps/` versus `libs/` ownership
- correct placement in `core`, `features`, `shared`, `testing`, and approved `ui` layers
- the critical `core` versus `shared` split and any `shared` -> `core` dependency violations
- invalid library dependencies
- missing or broken public APIs through `src/index.ts`
- path alias design in `tsconfig.base.json`
- feature libraries that should be split or shared code that should be extracted

Return the result in this format:

1. Findings
2. Open questions or assumptions
3. Recommended changes

Prioritize concrete architectural risks and dependency rule violations over style issues, especially `core` versus `shared` violations.