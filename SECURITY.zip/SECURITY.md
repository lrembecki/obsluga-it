# Security Policy

## Scope

This repository contains a reusable Angular project template. Security issues may affect downstream applications created from this template, so treat reports with care even when the repository does not contain production secrets or live services.

## Reporting A Vulnerability

- Do not report vulnerabilities through a public issue.
- Report the issue privately to the repository maintainers through your organization's approved security reporting channel.
- Include the affected files, the impact, reproduction steps, and any suggested mitigation.
- If no private reporting channel has been defined for this repository yet, establish one before adopting the template for production delivery.

## What To Report

- Vulnerable dependency usage or unsafe upgrade guidance.
- Insecure default authentication, authorization, or session handling patterns.
- Unsafe HTTP, storage, or serialization examples.
- Exposure of secrets, tokens, keys, or sensitive configuration guidance.
- Template guidance that would lead downstream applications to ship with known security weaknesses.

## Response Expectations

- Maintainers should acknowledge receipt promptly.
- Validate impact before public disclosure.
- Fix the template and the related guidance together when the issue is confirmed.
- Document any required downstream remediation when generated applications may already be affected.

## Secure Contribution Guidelines

- Never commit real secrets, credentials, connection strings, or certificates.
- Prefer secure defaults in sample code and documentation.
- Keep dependencies current and remove unused packages.
- Treat user input, browser storage, and external APIs as untrusted boundaries.
- Update documentation when a security-sensitive pattern changes.