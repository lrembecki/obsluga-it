# Product

## Product Summary

`PPG.GCSS.Angular` is the baseline product standard for new PPG.GCSS Angular repositories. It exists to give teams a consistent starting point for architecture, engineering workflow, and documentation governance instead of allowing each project to invent its own structure.

This repository now includes a runnable Nx Angular SSR workspace that demonstrates the standard in code, alongside the instructions, skills, architectural guidance, contribution rules, ADR templates, technical designs, and planning assets used to keep that baseline consistent.

The repository remains a reusable starting point, not a project-specific application. The runnable workspace proves the architecture, validation flow, and library boundaries without turning the baseline into a downstream product implementation.

## Problem Statement

Without a shared baseline, Angular projects drift into inconsistent folder structures, weak dependency boundaries, duplicated UI primitives, project-specific shortcuts, and undocumented architecture decisions. That makes delivery slower, review harder, and reuse across teams less reliable.

`PPG.GCSS.Angular` addresses that problem by defining a reusable standard that teams can adopt as the required starting point for new work.

## Target Users

- Platform and architecture teams defining the standard for new PPG.GCSS Angular workspaces.
- Delivery teams bootstrapping new applications from a shared, runnable baseline.
- Contributors maintaining the workspace, `.github/` guidance, and reusable documentation assets.

## Product Goals

- Provide a consistent Nx monorepo baseline for new PPG.GCSS Angular projects.
- Ship one runnable Angular SSR workspace that proves the standard end to end.
- Standardize the required architectural defaults: vertical slices, standalone Angular components, signals-first local state, SSR with hydration, OnPush change detection, schema-driven forms, and design-system-backed UI.
- Keep applications thin and push reusable implementation into the correct libraries and slices.
- Preserve clear dependency boundaries between app, feature, core, shared, and related supporting layers.
- Make `.github/` instructions and `docs/` assets part of the product, not optional metadata.
- Ensure repository changes strengthen the shared standard and remain reusable by future projects.

## Non-Goals

- Provide a finished business application or real backend integration in this repository.
- Capture one-off downstream project shortcuts or project-specific architecture exceptions.
- Allow business feature ownership to drift into applications instead of reusable slices and libraries.
- Encourage ad hoc UI primitives, direct DTO exposure in UI-facing code, or weakly typed TypeScript.
- Treat documentation changes as optional when architecture, workflow, or behavior changes.

## Product Scope

The template defines and maintains:

- Root Nx, TypeScript, lint, test, and build configuration for the baseline workspace.
- One thin Angular SSR application under `apps/ppg-gcss-angular`.
- One Playwright e2e project for workspace smoke validation.
- Core, feature, and shared libraries that demonstrate the baseline layering and dependency rules.
- Required engineering instructions under `.github/instructions/`.
- Task-specific Copilot skills under `.github/skills/`.
- Architecture decision support under `docs/architecture/decisions/`.
- Technical designs under `docs/technical-designs/`.
- Delivery and refactoring plans under `docs/plans/`.
- Repository-wide contribution and security expectations in the root Markdown assets.

The template includes the baseline serve, lint, unit-test, and build flows needed to validate the standard workspace. Teams extending the template should add project-specific targets only when the baseline targets are no longer sufficient.

## Required Product Defaults

Downstream projects created from this template are expected to start with these defaults:

- Nx monorepo structure.
- One thin Angular SSR application shell.
- Vertical slice architecture.
- Standalone Angular components.
- Signals-first local state.
- SSR with hydration.
- OnPush change detection by default.
- Schema-driven forms for business flows.
- Design-system-backed UI and approved UI wrapper layers.

These defaults are part of the product contract. Contributions should refine them carefully, not dilute them.

## Adoption Model

Teams adopting the template should:

1. Start from this repository as the workspace baseline.
2. Keep the root Nx config, `.github/`, and `docs/` assets aligned with the code they extend.
3. Keep new feature work inside the owning vertical slice and extract code into `libs/` only when it is genuinely reusable.
4. Record significant architectural choices as ADRs.
5. Keep implementation, documentation, and repository policies aligned as the workspace evolves.

## Contribution Bar

Every accepted change should reinforce the product standard:

- Keep changes incremental, focused, and reviewable.
- Start from existing patterns before introducing new abstractions.
- Preserve dependency boundaries between app, feature, ui, core, shared, and design-system concerns.
- Use strict TypeScript and avoid `any`.
- Keep DTOs out of UI-facing code and prefer explicit typed mappings at boundaries.
- Reuse approved UI libraries and design-system tokens instead of duplicating primitives.
- Add or update tests when behavior changes.
- Update documentation when structure, workflow, or architecture rules change.
- Record significant architecture decisions as ADRs when appropriate.

## Stewardship Priorities

The maintainers of this repository should prioritize:

- Keeping `.github/instructions/` and `.github/skills/` aligned when standards evolve.
- Keeping the runnable workspace, validation commands, and docs in sync.
- Removing placeholders quickly instead of leaving TODO-only guidance in the baseline.
- Protecting the repository from drift toward project-specific assumptions.
- Preserving the repository as a reusable standard for future PPG.GCSS Angular projects.

## Success Criteria

`PPG.GCSS.Angular` is succeeding when:

- New teams can start from a common, runnable baseline without redefining core architecture decisions or workspace setup.
- Contributions remain reusable across projects instead of solving only one local need.
- Dependency boundaries remain intact and understandable.
- Documentation stays current with the intended engineering workflow and validation path.
- Reviewers can confirm that changes fit the target architecture, include needed documentation updates, and add tests when behavior changes.